# CHANGELOG

## 2.1 · 单包化

- 新增 `references/23-card-forge.md`：把原独立 Skill `lustforge-card-forge` 的正文与字段规范合并为第 24 份手册，单包内只保留**一个** `SKILL.md`。
- 新增 `scripts/pack_full.py`：一条命令生成 `dist/lustforge-full.zip`（根 SKILL.md + 24 手册 + 9 脚本 + 5 资产 + tests + 4 张类型卡 + 文档），自带 `--verify` 解压自检（结构校验 + 20 条基准）。
- `pack_skill.py`：`assetPath` 增加跨盘符保护；允许 `tests/`、`examples/`、`docs/` 目录（不再误报非标准目录）。
- `SKILL.md` 脚本示例统一以 skill 根为基准（`tests/…`），并注明仓库内运行时替换为 `../../tests/…`。
- dist 收敛为**单一交付包** `lustforge-full.zip`（67 文件 / 277 KB），删除旧的 erotica / card-forge / master 三个 zip。
## 2.0 · 全量极致深度

### 新增手册（13 份，references/10–22）
- `10-group-scenes.md` 多人场景与群体动力学：站位图、分配句、待机、轮流三变体、群体分级、关系拓扑。
- `11-extreme-channels.md` 七条极端通道（痛/束缚/羞辱/过度刺激/排泄/见血/精神支配）+ 剂量开关 JSON + 复位机制。
- `12-genre-matrix.md` 15 个体裁的世界规则 → 身体设定 → 专属词 → 节拍偏置 → 失败模式。
- `13-register-and-dialect.md` 五档语域、同一句五种说法、称谓体系、方言与脏话本地化对照。
- `14-audience-axes.md` 女向/男向/共感/调教/纯情五轴的技术差异与混轴事故。
- `15-long-arc.md` S1–S5 关系弧线、情欲预算表、欲望债务、伏笔埋点、中段救援、三种结局。
- `16-dirty-talk-system.md` 七个功能位、分层词库、七条组合公式、话语与动作对齐、三忌四修。
- `17-sensory-atlas.md` 嗅/味/温/湿/质/声六库 + 体裁感官包 + 组合公式 + 三种失败。
- `18-props-and-devices.md` 道具四功能、衣物层数、束缚安全、空间锚库、清单化陷阱。
- `19-figures-of-speech.md` 四条纪律、陈词黑名单、八类意象池、通感、20 组替换对照。
- `20-anti-ai-and-censorship.md` 模糊词/三段式/抒情收尾/解释旁白/审查回避/万能形容词全表 + 规则集 JSON + 清洗前后对照。
- `21-rubric-and-cases.md` 五维评分细则、机器阈值表、20 条回归用例断言、人工四问、版本对比表。
- `22-corpus-engineering.md` 词条 schema、CSV 列定义、采集边界、归一化、三层去重、打标四问、抽样校验、质量指标、版本化。

### 新增脚本（4 个，共 8 个）
- `lexicon_build.py`：CSV → lexicon.json；简繁/异体归一、三元组去重、指标报告、`--inspect`/`--validate`。
- `rp_state.py`：纯文本四行状态栏生成与校验（行数/字数/键重复/HTML 检测/省略号）、剧情记忆维护（≤3 条/次）。
- `card_batch.py`：按列表批量建卡，支持 PNG 双块与 V3，输出汇总。
- `run_eval.py`：20 条回归基准执行器（score/min/max/must_terms/forbid_terms/forbid_categories/max_ai/min_jumps/dialogue_max_avg/short_min）。

### 脚本升级
- `explicit_lint.py`：词表引擎改为 slot 化；最长优先 + 区间遮蔽；权重计分；新增 `--sections` 逐段评分、`--suggest` 同槽位替换建议、`--lexicon` 外部词库、自动探测 `assets/lexicon.json`、审查回避词检测、抒情收尾占比、短句占比、词库版本回显。
- `card_build.py`：`--alternate-only`（覆盖模板自带开场）、自动创建输出目录、V3 输出、PNG 双块（去重旧块 + CRC 正确）。
- `card_batch.py`：修复 `--template` 位置错误；子进程 UTF-8 解码；备选开场默认覆盖。
- `pack_skill.py`：引用路径校验、Python 语法检查、512 KiB 限制、manifest 生成。

### 新增资产
- `lexicon.json`：156 条词条 / 12 槽位（含 `w` 权重、`lv` 区间、`g` 性别、`note`），另含 `euphemism` / `censorship` / `ai_taste` / `exclude` / `summary_tails` 五组规则表。
- `worldbook-genres.json`：28 条体裁专属世界书条目（古风/ABO/人外/调教/校园/黑帮/星际/恐怖）。
- `tests/cards.json`：4 张类型卡模板（沈砚清 L3 古风 / 祁昀 L4 ABO / 渊 L5 人外 / 苏黎 L4 调教），可批量生成为 V3 JSON + PNG。
- `tests/lexicon-src/{anatomy,acts}.csv`：48 行词库源，演示 `lexicon_build` 全流程。

### 新增测试
- `tests/cases.json`：20 条回归基准（6 条文件引用 + 14 条内联），覆盖留白/标准/气味/重口/古风/三人/空间/克制/命令/温差/余韵/复述/女向/去 AI 味/未完成/调教/分配/归位/纯情/主动。
- `tests/samples/{l2,l5,abo,historical,group,ai}.md`：六个体裁样本，其中 `ai.md` 为负样本（应触发 4 条报警）。
- `tests/state-demo.md`：状态栏校验样本。
- 当前基线：**20/20 通过**。

### 调整
- L 档阈值：L3 `[2.0, 4.5]`、L4 `[3.5, 12]`（原 L4 下限 5.0 对 900–1500 字标准场景过严）。
- 换称上限按档位分级（L4 ≤2/百字、L5 ≤1/百字）。
- 逐段评分跳过 <30 字的对白/过渡段，段级阈值取整篇一半，消除噪音。
- `scene_plan.py`：6 拍压缩时保留 B10 临界。
- 词典遮蔽表新增 `顶端/吸气/雨水` 等非性语境搭配，修正误报。

## 1.0 · 骨架

- 主 Skill `lustforge-erotica`：SKILL.md + references 00–09 + 4 脚本 + 3 资产。
- 辅助 Skill `lustforge-card-forge`：建卡/校验/排障。
- 示例卡「林砚」（V2，12 条世界书、3 档开场）+ PNG 双块导出。
- 首次打包与实测：结构校验通过、示例卡双块可解析、L4 样本 lint 零报警。
