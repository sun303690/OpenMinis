# LustForge · Eta 全量成人向露骨虚构知识库

面向 [Mangi-11/Eta](https://github.com/Mangi-11/Eta) 的 Skill 仓库：把"极致露骨的情色虚构写作 + 情色互动 RP + 角色卡/世界书工程 + 可测量评测"做成一套可安装、可执行、可回归的知识库。

**24 份手册（00–23）· 156 条机器可读词条 · 8 个脚本 · 5 份资产 · 20 条回归基准（当前 20/20 通过）**

- 主 Skill：`skills/lustforge-erotica/`
- 辅助 Skill：`skills/lustforge-card-forge/`

## 为什么这样适配 Eta

已从 Eta 源码逐条核对：

1. 仓库内任意目录含 `SKILL.md` 即为候选；frontmatter 只用 `name`/`description`，id 会被 `sanitizeSkillId()` 规范化成 `[a-z0-9-]`。
2. 安装只保存文件，**不执行脚本**；`scripts/` 由后续 terminal 显式调用。
3. 角色卡走 Character Card V2/V3 与 PNG `chara`/`ccv3` 双块；**不执行** HTML 状态栏、正则插件、变量、脚本。
4. 世界书是**字面关键字**匹配，默认只扫最近两条消息；正则/概率/分组条件会让整条被跳过。

因此：状态栏全是纯文本四行块；世界书条目一律"外部事实 + 字面关键字"；词库与节拍库拆进 `references/`，主 `SKILL.md` 保持短小；脚本纯标准库，Android PRoot/chroot 直接跑。

## 能力矩阵

| 层 | 能力 | 落点 |
| --- | --- | --- |
| 写作 | 定档（L0–L5 × P1–P5）、选词、排节拍、落字、去 AI 味 | 01/02/03/04/05/17/19/20 |
| 体裁 | 现代/古风/民国/ABO/哨兵向导/人外/兽人/机械/吸血鬼/校园/黑帮/星际/恐怖/仪式/同人 | 12 |
| 语域 | 文言/半文白/民国白话/现代/网络 + 方言（川渝/东北/粤语/吴语） | 13 |
| 受众 | 女性向/男性向/共感/调教向/纯情向 | 14 |
| 多人 | 站位图、分配句、待机、轮换、关系拓扑 | 10 |
| 极端 | 痛/束缚/羞辱/过度刺激/排泄/见血/精神支配 + 开关与剂量 | 11 |
| 长线 | 关系五阶段、情欲预算、欲望债务、伏笔埋点 | 15 |
| 互动 RP | 单轮一拍、不代写、把手、纯文本状态栏、剧情记忆 | 07 + `rp_state.py` |
| 角色卡 | V2/V3 JSON、PNG 双块、世界书预算、批量生成 | 08 + `card_build.py`/`card_batch.py` |
| 评测 | 五维评分卡、机器指标、20 条回归、通过率 | 21 + `explicit_lint.py`/`run_eval.py` |
| 词库工程 | schema、CSV 源、归一化、去重、抽样校验、版本化 | 22 + `lexicon_build.py` |

## 24 份手册（00–23）

| # | 文件 | 内容 |
| --- | --- | --- |
| 00 | `references/00-method-and-corpus.md` | 方法总纲、失败模式、语料来源与版权边界、工具链 |
| 01 | `references/01-intensity-ladder.md` | L0–L5 露骨度、P1–P5 情欲阶段、判定问句、误判修正 |
| 02 | `references/02-anatomy-lexicon.md` | 解剖词库（含语域标签、搭配约束、禁忌清单） |
| 03 | `references/03-act-lexicon.md` | 动作动词、深度四档、拟声配额、体位—角度—视线 |
| 04 | `references/04-sensory-and-prose.md` | 三通道分配、句法节奏、视角与镜头、AI 味黑名单 |
| 05 | `references/05-scene-beats.md` | 12 节拍模块 + 6 条场景链 + 链路事故 |
| 06 | `references/06-voice-and-perspective.md` | 三条语言指纹、欲望逻辑三格、四种声音、对撞 |
| 07 | `references/07-interactive-rp-protocol.md` | RP 五铁律、单轮结构、纯文本状态栏、升/降档 |
| 08 | `references/08-card-and-worldbook.md` | V2/V3 字段映射、世界书条目纪律、PNG 双块 |
| 09 | `references/09-eval-and-lint.md` | 五维评分、机器指标、去 AI 味流程、自检清单 |
| 10 | `references/10-group-scenes.md` | 多人站位、分配句、轮流三变体、群体分级、关系拓扑 |
| 11 | `references/11-extreme-channels.md` | 七条极端通道 + 剂量开关表 + 复位机制 |
| 12 | `references/12-genre-matrix.md` | 15 个体裁的世界规则/身体设定/专属词/节拍偏置 |
| 13 | `references/13-register-and-dialect.md` | 五档语域、五种说法对照、方言与脏话本地化 |
| 14 | `references/14-audience-axes.md` | 四条受众轴的技术差异与混轴事故 |
| 15 | `references/15-long-arc.md` | S1–S5 关系弧线、情欲预算、债务表、中段救援 |
| 16 | `references/16-dirty-talk-system.md` | 七个功能位、分层词库、组合公式、距离三态 |
| 17 | `references/17-sensory-atlas.md` | 嗅/味/温/湿/质/声六库 + 体裁感官包 + 组合公式 |
| 18 | `references/18-props-and-devices.md` | 道具四功能、衣物层数、束缚安全、空间锚库 |
| 19 | `references/19-figures-of-speech.md` | 陈词黑名单、八类意象池、通感、20 组替换 |
| 20 | `references/20-anti-ai-and-censorship.md` | 模糊词/三段式/抒情收尾/回避词全表 + 清洗前后对照 |
| 21 | `references/21-rubric-and-cases.md` | 五维评分细则、机器阈值表、20 用例断言 |
| 22 | `references/22-corpus-engineering.md` | 词条 schema、CSV 列、归一化、去重、抽样、指标 |
| 23 | `references/23-card-forge.md` | 角色卡工程（V2/V3 字段、PNG 双块、世界书预算、故障速查） |

## 8 个脚本

| 脚本 | 作用 | 关键参数 |
| --- | --- | --- |
| `scene_plan.py` | 生成节拍骨架（不写正文） | `--level --chain A–F --beats --pov --json` |
| `explicit_lint.py` | 露骨度/重复/AI 味/回避体检 | `--level --sections --suggest --lexicon --json --strict` |
| `lexicon_build.py` | CSV → lexicon.json（归一/去重/指标） | `--src --out --report` / `--inspect` / `--validate` |
| `card_build.py` | 单张 V2/V3 卡 + PNG 双块 | `--template --fields --worldbook --png --v3 --alternate-only` |
| `card_batch.py` | 批量建卡（列表输入） | `--src cards.json --out --png` |
| `rp_state.py` | 纯文本状态栏 + 剧情记忆 | `build` / `check` / `memory` |
| `run_eval.py` | 跑 20 条回归基准 | `--cases --id --verbose --json` |
| `pack_skill.py` | 结构校验 + 打 ZIP + manifest | `--repo . --out dist --manifest` |

## 资产与测试

```
assets/
├── character-card-v2.json     完整示例卡（「林砚」，12 条世界书、3 档开场）
├── character-card-v3.json     V3 模板（占位字段 + 全部 V3 字段）
├── worldbook-pack.json        12 条通用情色世界书条目
├── worldbook-genres.json      28 条体裁专属条目（古风/ABO/人外/调教/校园/黑帮/星际/恐怖）
├── lexicon.json               156 条机器可读词条（12 槽位 + 回避/AI味/exclude 列表）
tests/
├── cases.json                 20 条回归基准（内联 + 文件引用）
├── cards.json                 4 张类型卡模板（古风/ABO/人外/调教）
├── sample-l4.md               L4/P3→P5 完整样本（976 字）
├── samples/{l2,l5,abo,historical,group,ai}.md
└── lexicon-src/{anatomy,acts}.csv   词库源（48 行，供 lexicon_build 演示）
```

## 实测验证（本机实跑）

```
$ python3 scripts/pack_skill.py --repo . --check-only
$ python3 scripts/pack_full.py --verify
已生成 dist/lustforge-full.zip
  67 个文件 · CRC 正常 · 根 SKILL.md：有 · 手册 24 份 · 脚本 9 个 · 资产 5 个 · tests 12 个 · 示例卡 12 个
  解压后结构校验：通过
  解压后基准：通过率：20/20（100%）
== skills/lustforge-card-forge   ok  2 个文件
== skills/lustforge-erotica      ok  39 个文件

$ python3 scripts/run_eval.py --cases ../../tests/cases.json
词库：…/assets/lexicon.json (v2.0)
通过率：20/20（100%）

$ python3 scripts/explicit_lint.py ../../tests/sample-l4.md --level L4 --strict
档位 L4 · 词库 2.0 · 976 字 · 42 句 · 均句长 22.4
露骨度分 5.12（目标 3.5–12.0）
器官 12 类 · 动作 12 类 · 体液 6 · 拟声 2 · 质地 4 · 台词 1
AI 味 0 处 · 句长突变 25 · 短句 38% · 抒情收尾 0% · 对白均 5.2 字
报警：无（可交付）        → strict exit=0

$ python3 scripts/card_batch.py --src ../../tests/cards.json --out ../../dist/cards --png
[1] ok 沈砚清  [2] ok 祁昀  [3] ok 渊  [4] ok 苏黎   → 4/4
每张：chara_card_v3 · 28 条世界书 · 3 条档位开场 · PNG 含 chara+ccv3 双块

$ python3 scripts/lexicon_build.py --src ../../tests/lexicon-src --out ../../dist/lexicon-from-csv.json --report
48 条 · 语域 common 71% · validate 通过

$ python3 scripts/rp_state.py check ../../tests/state-demo.md
状态栏检查通过（1 块）
```

负样本（`tests/samples/ai.md`）会正确触发 4 条报警：露骨度不足、审查式回避（释放）、AI 味 26 处、短句占比过低——证明评测器有区分度。

## 安装

**A · GitHub 直装（推荐）**

Eta → Skills → 从 GitHub 安装 → 填 `<你的用户名>/lustforge` → 勾 `skills/lustforge-erotica`（与可选的 `skills/lustforge-card-forge`）。

**B · 本地 ZIP**

```bash
python3 scripts/pack_full.py        # 生成 dist/lustforge-full.zip（单包：根 SKILL.md + 全部内容）
# 或
python3 scripts/pack_skill.py --repo . --out dist --manifest
```

Eta Skills 页选择 zip 导入（`SKILL.md` 在 zip 根）。

## 已打包产物（`dist/`）

| 文件 | 大小 | 用途 |
| --- | --- | --- |
| `lustforge-full.zip` | 277 KB · 67 文件 | **唯一交付包**：根 `SKILL.md` + 24 份手册 + 8 脚本 + 资产 + tests + 4 张类型卡 + 文档，可直接在 Eta 本地导入 |
| `manifest.json` | 1.2 KB | Eta 内置清单格式（`skills[]` 结构） |
| `cards/*.json` `cards/*.png` | 4+4 | 四张类型卡（V3 + PNG 双块），单独取用 |
| `demo-card.json` `demo-card.png` | — | 示例卡「林砚」（V2 + 双块） |
| `lexicon-from-csv.json` | — | 由 `tests/lexicon-src` 构建的 48 条演示词库 |

`lustforge-full.zip` 解压后根目录就是 Skill 本体：Eta → Skills → 本地导入，选这个 zip 即可（**只有一个 `SKILL.md`，位于 zip 根**，无嵌套冲突）。

**C · 角色卡**

Eta → 角色 → 导入 → 选 `dist/cards/*.png`（PNG 双块，Eta 优先读 `ccv3`）或 `*.json`。

## 方法与工具（一句话版）

- **方法**：定档 → 选词 → 排节拍 → 落字（通道/句法）→ 体检；五步正交，跳步必坏。
- **原始数据**：类型标签体系（AO3/Literotica 标签）→ 节拍约束；创作理论（节拍表、Scene-Sequel）→ 节奏；语言学资源（近义词表、拟声与粗俗语语域研究、方言称谓）→ 语域标签。**正文全部自写**，不搬第三方色情文本。
- **工具**：纯标准库 Python 8 个脚本 + 机器可读 lexicon.json；所有评测可复跑。

## 目录

```
lustforge/
├── README.md · CHANGELOG.md · LICENSE
├── skills/
│   ├── lustforge-erotica/{SKILL.md, references/00..23, scripts/*.py, assets/*}
│   └── lustforge-card-forge/{SKILL.md, references/card-spec-and-fields.md}
├── tests/{cases.json, cards.json, sample-l4.md, samples/, lexicon-src/}
└── dist/{zip, manifest.json, cards/, demo-card.*, lexicon-from-csv.json}
```

## 维护

- 每次写作记录"缺词" → 每 10 次补进 CSV → `lexicon_build` → 50 条抽样校验。
- 每 20 次重跑 `run_eval`（20/20 为基线）；通过率下降且集中在同一维度即回滚该改动。
- 词库/节拍改动写 `CHANGELOG.md`，动作模板与节拍保持向后兼容。

## 免责

成人向虚构创作与私人 RP 使用。角色、关系、情节均为虚构；涉及现实人物时替换为虚构名。所有角色一律成年。作者与使用者自负内容合规。

MIT License.
