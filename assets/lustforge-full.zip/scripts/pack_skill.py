#!/usr/bin/env python3
"""pack_skill.py — 校验 Skill 结构并打包成 Eta 可本地导入的 ZIP。

校验项（与 Eta 运行时对齐）：
  - SKILL.md 存在且带 YAML frontmatter
  - name 只含 [a-z0-9-]，且与目录名一致（Eta 会用 sanitizeSkillId 规范化）
  - description 非空且长度合理（触发契约）
  - 正文引用的 references/、scripts/、assets/ 路径真实存在
  - scripts/*.py 能通过 compile() 语法检查
  - 单文件 < 512 KiB（Eta 单次写入上限）

示例：
  python3 scripts/pack_skill.py --skill skills/lustforge-erotica --out dist
  python3 scripts/pack_skill.py --repo . --all --out dist --manifest
"""

from __future__ import annotations

import argparse
import json
import os
import re
import sys
import zipfile
from typing import Dict, List, Tuple

MAX_FILE_BYTES = 512 * 1024
SKIP_DIRS = {"__pycache__", ".git", ".idea", "dist", "node_modules"}
PATH_REF = re.compile(r"(references|scripts|assets)/[A-Za-z0-9._\-/]+")


def parse_frontmatter(text: str) -> Tuple[Dict[str, str], str]:
    if not text.startswith("---"):
        return {}, text
    end = text.find("\n---", 3)
    if end <= 0:
        return {}, text
    block = text[3:end].strip("\n\r")
    meta: Dict[str, str] = {}
    for line in block.splitlines():
        m = re.match(r"^([A-Za-z0-9_-]+):\s*(.*)$", line)
        if m:
            meta[m.group(1)] = m.group(2).strip().strip("'\"")
    return meta, text[end + 4:]


def iter_files(root: str) -> List[str]:
    out: List[str] = []
    for base, dirs, files in os.walk(root):
        dirs[:] = [d for d in dirs if d not in SKIP_DIRS]
        for f in files:
            if f.endswith((".pyc", ".pyo")):
                continue
            out.append(os.path.join(base, f))
    return sorted(out)


def validate(skill_dir: str) -> Tuple[List[str], List[str], Dict[str, str]]:
    errors: List[str] = []
    warnings: List[str] = []
    skill_md = os.path.join(skill_dir, "SKILL.md")
    if not os.path.isfile(skill_md):
        return [f"缺少 SKILL.md：{skill_md}"], [], {}

    with open(skill_md, "r", encoding="utf-8") as fh:
        text = fh.read()
    meta, body = parse_frontmatter(text)
    if not meta:
        errors.append("SKILL.md 缺少 YAML frontmatter")
    name = meta.get("name", "")
    desc = meta.get("description", "")
    dirname = os.path.basename(skill_dir.rstrip(os.sep))
    if not name:
        errors.append("frontmatter 缺少 name")
    elif not re.fullmatch(r"[a-z0-9-]+", name):
        errors.append(f"name «{name}» 含非法字符（Eta 会规范化为 [a-z0-9-]）")
    elif name != dirname:
        warnings.append(f"name «{name}» 与目录名 «{dirname}» 不一致（yaml 优先）")
    if not desc:
        errors.append("frontmatter 缺少 description（触发契约）")
    elif len(desc) < 20:
        warnings.append(f"description 偏短（{len(desc)} 字），触发可能不稳")
    elif len(desc) > 600:
        warnings.append(f"description 偏长（{len(desc)} 字），建议压到 400 字内")

    refs = sorted({m.group(0).rstrip(".,);:") for m in PATH_REF.finditer(body)})
    for ref in refs:
        if not os.path.exists(os.path.join(skill_dir, ref)):
            errors.append(f"正文引用了不存在的路径：{ref}")

    files = iter_files(skill_dir)
    for f in files:
        size = os.path.getsize(f)
        rel = os.path.relpath(f, skill_dir).replace("\\", "/")
        if size > MAX_FILE_BYTES:
            errors.append(f"文件超 512 KiB：{rel}（{size} 字节）")
        if f.endswith(".py"):
            try:
                with open(f, "r", encoding="utf-8") as fh:
                    compile(fh.read(), rel, "exec")
            except SyntaxError as exc:
                errors.append(f"Python 语法错误：{rel}:{exc.lineno} {exc.msg}")
        if rel.split("/")[0] not in {"references", "scripts", "assets", "tests", "examples", "docs", "SKILL.md"} and "/" in rel:
            warnings.append(f"非标准目录：{rel}")

    if not os.path.isdir(os.path.join(skill_dir, "references")):
        warnings.append("无 references/：长知识型 Skill 建议拆分")
    return errors, warnings, {"name": name, "description": desc, "files": str(len(files))}


def build_zip(skill_dir: str, out_dir: str) -> str:
    os.makedirs(out_dir, exist_ok=True)
    skill_id = os.path.basename(skill_dir.rstrip(os.sep))
    target = os.path.join(out_dir, f"{skill_id}.zip")
    with zipfile.ZipFile(target, "w", zipfile.ZIP_DEFLATED) as zf:
        for f in iter_files(skill_dir):
            rel = os.path.relpath(f, skill_dir).replace("\\", "/")
            zf.write(f, rel)
    return target


def main(argv: List[str] | None = None) -> int:
    p = argparse.ArgumentParser(description="校验并打包 Skill（Eta 本地导入用）")
    p.add_argument("--skill", action="append", default=[], help="Skill 目录，可重复")
    p.add_argument("--repo", help="仓库根：自动发现 skills/* 下含 SKILL.md 的目录")
    p.add_argument("--all", action="store_true", help="配合 --repo，打包全部候选")
    p.add_argument("--out", default="dist", help="输出目录")
    p.add_argument("--manifest", action="store_true", help="同时写 manifest.json（Eta 内置清单格式）")
    p.add_argument("--check-only", action="store_true", help="只校验不打包")
    args = p.parse_args(argv)

    skills: List[str] = list(args.skill)
    if args.repo:
        base = os.path.join(args.repo, "skills")
        if not os.path.isdir(base):
            print(f"找不到 {base}", file=sys.stderr)
            return 1
        for name in sorted(os.listdir(base)):
            cand = os.path.join(base, name)
            if os.path.isfile(os.path.join(cand, "SKILL.md")):
                skills.append(cand)
    if not skills:
        print("没有可处理的 Skill：用 --skill 或 --repo", file=sys.stderr)
        return 1

    failed = 0
    manifest: List[Dict[str, str]] = []
    for skill_dir in skills:
        print(f"\n== {skill_dir}")
        errors, warnings, meta = validate(skill_dir)
        for w in warnings:
            print(f"  warn  {w}")
        for e in errors:
            print(f"  ERROR {e}")
        if errors:
            failed += 1
            continue
        print(f"  ok    {meta.get('name')} · {meta.get('files')} 个文件")
        if meta:
            base = args.repo or os.path.dirname(os.path.abspath(skill_dir))
            try:
                asset_path = os.path.relpath(skill_dir, base).replace("\\", "/")
            except ValueError:  # 跨盘符时退回目录名
                asset_path = os.path.basename(skill_dir.rstrip(os.sep))
            manifest.append({
                "id": meta.get("name", ""),
                "name": meta.get("name", ""),
                "description": meta.get("description", ""),
                "assetPath": asset_path,
                "hasScripts": os.path.isdir(os.path.join(skill_dir, "scripts")),
                "hasReferences": os.path.isdir(os.path.join(skill_dir, "references")),
                "hasAssets": os.path.isdir(os.path.join(skill_dir, "assets")),
                "hasEvals": os.path.isdir(os.path.join(skill_dir, "evals")),
            })
        if not args.check_only:
            target = build_zip(skill_dir, args.out)
            print(f"  zip   {target}（{os.path.getsize(target)} 字节）")

    if args.manifest and manifest:
        os.makedirs(args.out, exist_ok=True)
        path = os.path.join(args.out, "manifest.json")
        with open(path, "w", encoding="utf-8") as fh:
            json.dump({"skills": manifest}, fh, ensure_ascii=False, indent=2)
            fh.write("\n")
        print(f"\nmanifest → {path}")

    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
