#!/usr/bin/env python3
"""lexicon_build.py — 从 CSV 源构建 lexicon.json（归一化 / 去重 / 打标 / 指标报告）。

配合 references/22-corpus-engineering.md。输出 schema 见同文件的「词条 schema」一节。

示例：
    python3 scripts/lexicon_build.py --src ../../tests/lexicon-src --out assets/lexicon.json --report
    python3 scripts/lexicon_build.py --inspect assets/lexicon.json
    python3 scripts/lexicon_build.py --validate assets/lexicon.json
"""

from __future__ import annotations

import argparse
import csv
import json
import os
import sys
import unicodedata
from collections import Counter, defaultdict
from typing import Any, Dict, List, Tuple

CSV_COLUMNS = ["term", "slot", "reg", "lv_min", "lv_max", "gender", "genres", "w", "note"]
REG_VALUES = {"literary", "common", "coarse", "dirty"}
GENDER_VALUES = {"f", "m", "n"}
SLOT_PREFIXES = ("anatomy", "act", "fluid", "sound", "texture", "smell", "dirty_talk")

# 少量繁→简 / 异体归一（可按需扩充）
NORMALIZE_MAP = str.maketrans({
    "裏": "里", "著": "着", "麼": "么", "髮": "发", "幹": "干",
    "屄": "逼", "隂": "阴", "莖": "茎", "龜": "龟", "頭": "头",
})


def normalize_term(term: str) -> str:
    t = unicodedata.normalize("NFKC", term.strip())
    t = t.translate(NORMALIZE_MAP)
    return t.strip(" \t\r\n，。、；：!?！？…—·\"'“”‘’")


def read_csv_dir(src: str) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    paths = []
    if os.path.isdir(src):
        paths = [os.path.join(src, f) for f in sorted(os.listdir(src)) if f.endswith(".csv")]
    elif os.path.isfile(src):
        paths = [src]
    if not paths:
        raise SystemExit(f"没有找到 CSV：{src}")
    for path in paths:
        with open(path, "r", encoding="utf-8-sig", newline="") as fh:
            reader = csv.DictReader(fh)
            missing = [c for c in CSV_COLUMNS if c not in (reader.fieldnames or [])]
            if missing:
                raise SystemExit(f"{os.path.basename(path)} 缺列：{missing}")
            for lineno, raw in enumerate(reader, start=2):
                term = normalize_term(raw.get("term", ""))
                if not term:
                    continue
                slot = (raw.get("slot") or "").strip()
                if not slot.startswith(SLOT_PREFIXES):
                    print(f"  skip {os.path.basename(path)}:{lineno} 未知槽位 {slot!r}", file=sys.stderr)
                    continue
                reg = (raw.get("reg") or "common").strip()
                if reg not in REG_VALUES:
                    print(f"  warn {os.path.basename(path)}:{lineno} 语域 {reg!r} → common", file=sys.stderr)
                    reg = "common"
                gender = (raw.get("gender") or "n").strip()
                if gender not in GENDER_VALUES:
                    gender = "n"
                try:
                    lv_min = int(raw.get("lv_min") or 3)
                    lv_max = int(raw.get("lv_max") or 5)
                except ValueError:
                    print(f"  skip {os.path.basename(path)}:{lineno} 档位非整数", file=sys.stderr)
                    continue
                if lv_min > lv_max:
                    print(f"  skip {os.path.basename(path)}:{lineno} lv_min>lv_max", file=sys.stderr)
                    continue
                genres = (raw.get("genres") or "*").replace("|", ",").split(",")
                try:
                    weight = float(raw.get("w") or 1.0)
                except ValueError:
                    weight = 1.0
                rows.append({
                    "t": term,
                    "slot": slot,
                    "reg": reg,
                    "lv": [max(0, lv_min), min(5, lv_max)],
                    "g": gender,
                    "genre": [g.strip() for g in genres if g.strip()] or ["*"],
                    "w": round(max(0.2, min(2.0, weight)), 2),
                    "note": (raw.get("note") or "").strip(),
                })
    return rows


def dedupe(rows: List[Dict[str, Any]]) -> Tuple[List[Dict[str, Any]], int]:
    """主键 (slot, 归一化词形, reg)；合并 note，保留更高权重。"""
    merged: Dict[Tuple[str, str, str], Dict[str, Any]] = {}
    dropped = 0
    for row in rows:
        key = (row["slot"], normalize_term(row["t"]), row["reg"])
        if key in merged:
            kept = merged[key]
            kept["w"] = max(kept["w"], row["w"])
            kept["lv"] = [min(kept["lv"][0], row["lv"][0]), max(kept["lv"][1], row["lv"][1])]
            if row["note"] and row["note"] not in kept["note"]:
                kept["note"] = (kept["note"] + "；" + row["note"]).strip("；")
            genre = set(kept["genre"]) | set(row["genre"])
            kept["genre"] = ["*"] if "*" in genre else sorted(genre)
            dropped += 1
        else:
            merged[key] = dict(row)
    return list(merged.values()), dropped


def build(rows: List[Dict[str, Any]], version: str) -> Dict[str, Any]:
    slots: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
    for row in rows:
        slots[row["slot"]].append({
            "t": row["t"], "reg": row["reg"], "lv": row["lv"],
            "g": row["g"], "w": row["w"], "note": row["note"],
        })
    for name in slots:
        slots[name].sort(key=lambda e: (-e["w"], e["t"]))
    return {
        "version": version,
        "generated_by": "lustforge lexicon_build",
        "slots": {k: slots[k] for k in sorted(slots)},
        "euphemism": [], "censorship": [], "ai_taste": [], "exclude": [], "summary_tails": [],
    }


def report(lex: Dict[str, Any], dropped: int) -> str:
    lines = ["=== lexicon 指标 ==="]
    total = sum(len(v) for v in lex["slots"].values())
    lines.append(f"词条总数：{total}（去重丢弃 {dropped} 条）")
    regs: Counter = Counter()
    for entries in lex["slots"].values():
        for e in entries:
            regs[e["reg"]] += 1
    lines.append("语域分布：" + ", ".join(f"{k}={v}" for k, v in sorted(regs.items())))
    lines.append("")
    lines.append(f"{'槽位':<20}{'条数':>6}{'最低档':>8}{'最高权重':>10}")
    for name, entries in lex["slots"].items():
        lo = min(e["lv"][0] for e in entries) if entries else 0
        hi = max(e["w"] for e in entries) if entries else 0
        flag = "" if len(entries) >= 15 else "  ← 覆盖率不足(<15)"
        lines.append(f"{name:<20}{len(entries):>6}{lo:>8}{hi:>10}{flag}")
    l5 = sum(1 for v in lex["slots"].values() for e in v if e["lv"][0] >= 5)
    lines.append(f"\nL5 专用词条：{l5}（目标 ≥25）")
    if total:
        common_ratio = regs.get("common", 0) / total
        lines.append(f"common 占比：{common_ratio:.0%}（目标 40–60%）")
    return "\n".join(lines)


def validate(path: str) -> int:
    try:
        lex = json.load(open(path, "r", encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        print(f"读取失败：{exc}", file=sys.stderr)
        return 1
    problems: List[str] = []
    if "slots" not in lex:
        problems.append("缺少 slots")
    seen = set()
    for name, entries in (lex.get("slots") or {}).items():
        for e in entries:
            for key in ("t", "reg", "lv", "g", "w"):
                if key not in e:
                    problems.append(f"{name}:{e.get('t', '?')} 缺字段 {key}")
            if e.get("reg") not in REG_VALUES:
                problems.append(f"{name}:{e.get('t')} 语域非法 {e.get('reg')}")
            lv = e.get("lv") or [0, 0]
            if not (isinstance(lv, list) and len(lv) == 2 and 0 <= lv[0] <= lv[1] <= 5):
                problems.append(f"{name}:{e.get('t')} 档位非法 {lv}")
            key = (name, e.get("t"), e.get("reg"))
            if key in seen:
                problems.append(f"{name}:{e.get('t')}({e.get('reg')}) 重复")
            seen.add(key)
    for line in problems[:20]:
        print(f"  ERROR {line}")
    print(f"\n{'通过' if not problems else f'{len(problems)} 个问题'}：{path}")
    return 0 if not problems else 1


def inspect(path: str) -> int:
    lex = json.load(open(path, "r", encoding="utf-8"))
    print(f"version={lex.get('version')}  slots={len(lex.get('slots') or {})}")
    for name, entries in (lex.get("slots") or {}).items():
        sample = ", ".join(e["t"] for e in entries[:6])
        print(f"  {name:<18} {len(entries):>3}  {sample}{' …' if len(entries) > 6 else ''}")
    for key in ("euphemism", "censorship", "ai_taste", "exclude"):
        vals = lex.get(key) or []
        print(f"  {key:<12} {len(vals):>3}  {', '.join(vals[:8])}")
    return 0


def main(argv: List[str] | None = None) -> int:
    p = argparse.ArgumentParser(description="构建/校验 lexicon.json")
    p.add_argument("--src", help="CSV 目录或单文件")
    p.add_argument("--out", help="输出 lexicon.json")
    p.add_argument("--version", default="2.1")
    p.add_argument("--report", action="store_true", help="打印指标报告")
    p.add_argument("--inspect", help="查看已有 lexicon.json")
    p.add_argument("--validate", help="校验已有 lexicon.json")
    args = p.parse_args(argv)

    if args.inspect:
        return inspect(args.inspect)
    if args.validate:
        return validate(args.validate)
    if not args.src or not args.out:
        print("需要 --src 与 --out（或 --inspect/--validate）", file=sys.stderr)
        return 1

    rows = read_csv_dir(args.src)
    rows, dropped = dedupe(rows)
    lex = build(rows, args.version)
    os.makedirs(os.path.dirname(os.path.abspath(args.out)), exist_ok=True)
    with open(args.out, "w", encoding="utf-8") as fh:
        json.dump(lex, fh, ensure_ascii=False, indent=2)
        fh.write("\n")
    print(f"已写入 {args.out}（{sum(len(v) for v in lex['slots'].values())} 条）")
    if args.report:
        print(report(lex, dropped))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
