#!/usr/bin/env python3
"""rp_state.py — 纯文本状态栏与剧情记忆维护（Eta 角色会话用 / LustForge）。

Eta 不渲染 HTML 状态栏，所以状态栏必须是四行纯文本：
    【位】地点/体位
    【衣】剩余衣物
    【状】湿润/紧度/疼感/心跳
    【话】对方还没回答的那句

示例：
    python3 scripts/rp_state.py build --loc "浴室，站立，一条腿被抬着" \
        --wear "衬衫全开，裙子在腰上" --state "腿在抖，里面烫" --line "求我"
    python3 scripts/rp_state.py check draft.md
    python3 scripts/rp_state.py memory --file memory.md --add "关系：她开始主动要"
    python3 scripts/rp_state.py memory --file memory.md --show
"""

from __future__ import annotations

import argparse
import os
import re
import sys
from typing import List

KEYS = ["位", "衣", "状", "话"]
LINE_MAX = 20
MEMORY_LIMIT = 3


def build(loc: str, wear: str, state: str, line: str) -> str:
    rows = [("位", loc), ("衣", wear), ("状", state), ("话", line)]
    out = []
    for key, value in rows:
        value = (value or "").strip()
        if not value:
            value = "[未填]"
        out.append(f"【{key}】{value}")
    return "\n".join(out)


def check(path: str) -> int:
    try:
        text = open(path, "r", encoding="utf-8").read()
    except OSError as exc:
        print(f"读取失败：{exc}", file=sys.stderr)
        return 1

    problems: List[str] = []
    warnings: List[str] = []

    if re.search(r"<(div|span|table|b|i|br)\b", text, re.I):
        problems.append("出现 HTML 标签（Eta 不渲染，会被当纯文本显示）")

    blocks = re.findall(r"(?:【[位衣状话]】[^\n]*\n?){1,4}", text)
    if not blocks:
        warnings.append("未找到状态栏（若本段不需要状态栏可忽略）")
    for bi, block in enumerate(blocks, start=1):
        lines = [ln for ln in block.strip().splitlines() if ln.strip()]
        keys_found = [m.group(1) for ln in lines for m in [re.match(r"【([位衣状话])】", ln)] if m]
        if len(lines) > 4:
            problems.append(f"状态栏 #{bi} 有 {len(lines)} 行（上限 4）")
        if not keys_found:
            warnings.append(f"状态栏 #{bi} 未用【位/衣/状/话】键名")
        for ln in lines:
            body = re.sub(r"^【[位衣状话]】", "", ln).strip()
            if len(body) > LINE_MAX:
                problems.append(f"状态栏 #{bi} 某行 {len(body)} 字（上限 {LINE_MAX}）：「{body[:16]}…」")
            if "…" in body or "..." in body:
                warnings.append(f"状态栏 #{bi} 出现省略号：用「未填」或删该行")
        dup = {k for k in keys_found if keys_found.count(k) > 1}
        if dup:
            problems.append(f"状态栏 #{bi} 键重复：{sorted(dup)}")

    for p in problems:
        print(f"ERROR {p}")
    for w in warnings:
        print(f"warn  {w}")
    if not problems:
        print(f"状态栏检查通过（{len(blocks)} 块）")
    return 0 if not problems else 1


def memory(file: str, add: List[str] | None, show: bool) -> int:
    path = file
    existing: List[str] = []
    if os.path.isfile(path):
        existing = [ln for ln in open(path, "r", encoding="utf-8").read().splitlines() if ln.strip()]

    if show or not add:
        if not existing:
            print("（记忆为空）")
        else:
            for ln in existing:
                print(ln)
        return 0

    if len(add) > MEMORY_LIMIT:
        print(f"警告：一次写入 {len(add)} 条，建议 ≤{MEMORY_LIMIT}", file=sys.stderr)
    for item in add:
        item = item.strip()
        if not item:
            continue
        if item in existing:
            continue
        existing.append(item if item.startswith(("-", "*")) else f"- {item}")

    with open(path, "w", encoding="utf-8") as fh:
        fh.write("\n".join(existing) + "\n")
    print(f"已写入 {path}（{len(existing)} 条）")
    print("提醒：只记关系与设定变更，不记过程细节；上限 3 条/次，改写而非堆叠。")
    return 0


def main(argv: List[str] | None = None) -> int:
    p = argparse.ArgumentParser(description="纯文本状态栏与剧情记忆（Eta 兼容）")
    sub = p.add_subparsers(dest="cmd", required=True)

    b = sub.add_parser("build", help="生成四行状态栏")
    b.add_argument("--loc", default="")
    b.add_argument("--wear", default="")
    b.add_argument("--state", default="")
    b.add_argument("--line", default="")

    c = sub.add_parser("check", help="校验文本中的状态栏")
    c.add_argument("path")

    m = sub.add_parser("memory", help="维护剧情记忆")
    m.add_argument("--file", default="memory.md")
    m.add_argument("--add", action="append", default=[], help="新增一条，可重复（≤3）")
    m.add_argument("--show", action="store_true")

    args = p.parse_args(argv)
    if args.cmd == "build":
        print(build(args.loc, args.wear, args.state, args.line))
        return 0
    if args.cmd == "check":
        return check(args.path)
    return memory(args.file, args.add, args.show)


if __name__ == "__main__":
    raise SystemExit(main())
