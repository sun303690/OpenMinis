#!/usr/bin/env python3
"""card_build.py — 生成 Eta / 酒馆兼容角色卡（Character Card V2 / V3），可选写 PNG 双块。

设计依据：
  - Character Card V2: spec="chara_card_v2", spec_version="2.0", data{...}
  - Character Card V3: spec="chara_card_v3", spec_version="3.0", data{...}
  - PNG 文本块：chara = V2 base64(JSON)，ccv3 = V3 base64(JSON)

示例：
  python3 scripts/card_build.py --template assets/character-card-v2.json \
      --name "林砚" --personality "…" --out dist/linyan.json
  python3 scripts/card_build.py --template assets/character-card-v3.json \
      --fields my-fields.json --worldbook my-book.json --out dist/x.json --png dist/x.png
"""

from __future__ import annotations

import argparse
import base64
import json
import os
import struct
import sys
import zlib
from typing import Any, Dict, List

# card 字段名 → argparse dest（两者不总是一致）
FIELD_ARGS = {
    "description": "description",
    "personality": "personality",
    "scenario": "scenario",
    "first_mes": "first_mes",
    "mes_example": "mes_example",
    "creator_notes": "creator_notes",
    "system_prompt": "system_prompt",
    "post_history_instructions": "post_history",
    "creator": "creator",
    "character_version": "version",
}


def load_json(path: str) -> Dict[str, Any]:
    with open(path, "r", encoding="utf-8") as fh:
        return json.load(fh)


def normalize_card(card: Dict[str, Any]) -> Dict[str, Any]:
    """把 V1 扁平卡或任意输入规整成 V2 外壳，便于统一处理。"""
    if "data" in card and ("spec" in card or "name" not in card):
        card.setdefault("spec", "chara_card_v2")
        card.setdefault("spec_version", "2.0")
        card.setdefault("data", {})
        return card
    data = {k: v for k, v in card.items() if k not in {"spec", "spec_version", "data"}}
    return {"spec": "chara_card_v2", "spec_version": "2.0", "data": data}


def set_field(data: Dict[str, Any], key: str, value: str | None) -> None:
    if value is not None and value != "":
        data[key] = value


def ensure_book(card: Dict[str, Any], book: Dict[str, Any] | None) -> None:
    if book is None:
        card["data"].setdefault("character_book", {"entries": []})
        return
    if isinstance(book, list):
        book = {"entries": book}
    card["data"]["character_book"] = book


def to_v3(card: Dict[str, Any]) -> Dict[str, Any]:
    v3 = {"spec": "chara_card_v3", "spec_version": "3.0",
          "data": dict(card["data"])}
    v3["data"].setdefault("nickname", "")
    v3["data"].setdefault("creator_notes_multilingual", {})
    v3["data"].setdefault("group_only_greetings", [])
    v3["data"].setdefault("source", [])
    v3["data"].setdefault("assets", [])
    return v3


# ---------------------------------------------------------------- PNG helpers


def _chunks(png: bytes):
    if png[:8] != b"\x89PNG\r\n\x1a\n":
        raise ValueError("不是有效 PNG")
    pos = 8
    while pos < len(png):
        (length,) = struct.unpack(">I", png[pos:pos + 4])
        ctype = png[pos + 4:pos + 8]
        data = png[pos + 8:pos + 8 + length]
        yield ctype, data
        pos += 12 + length


def _chunk(ctype: bytes, data: bytes) -> bytes:
    return (
        struct.pack(">I", len(data))
        + ctype
        + data
        + struct.pack(">I", zlib.crc32(ctype + data) & 0xFFFFFFFF)
    )


def _placeholder_png(width: int = 512, height: int = 768) -> bytes:
    raw = bytearray()
    for y in range(height):
        raw.append(0)
        base = 24 + int(40 * y / max(1, height - 1))
        for x in range(width):
            r = min(255, base + int(30 * x / max(1, width - 1)))
            g = min(255, 12 + (base // 3))
            b = min(255, 40 + (base // 2))
            if (x // 16 + y // 16) % 2 == 0:
                r, g, b = min(255, r + 10), min(255, g + 6), min(255, b + 8)
            raw += bytes((r, g, b))
    ihdr = struct.pack(">IIBBBBB", width, height, 8, 2, 0, 0, 0)
    return (
        b"\x89PNG\r\n\x1a\n"
        + _chunk(b"IHDR", ihdr)
        + _chunk(b"IDAT", zlib.compress(bytes(raw), 9))
        + _chunk(b"IEND", b"")
    )


def write_card_png(path: str, v2: Dict[str, Any], v3: Dict[str, Any], base_png: str | None) -> None:
    if base_png and os.path.isfile(base_png):
        with open(base_png, "rb") as fh:
            png = fh.read()
    else:
        png = _placeholder_png()

    payloads = {
        b"chara": base64.b64encode(json.dumps(v2, ensure_ascii=False).encode("utf-8")),
        b"ccv3": base64.b64encode(json.dumps(v3, ensure_ascii=False).encode("utf-8")),
    }
    out = bytearray(png[:8])
    for ctype, data in _chunks(png):
        if ctype == b"IEND":
            for key, val in payloads.items():
                out += _chunk(b"tEXt", key + b"\x00" + val)
        if ctype in (b"tEXt", b"iTXt", b"zTXt"):
            key = data.split(b"\x00", 1)[0]
            if key in payloads:
                continue  # 替换旧角色块
        out += _chunk(ctype, data)
    with open(path, "wb") as fh:
        fh.write(bytes(out))


# ---------------------------------------------------------------- main


def main(argv: List[str] | None = None) -> int:
    p = argparse.ArgumentParser(description="生成 Character Card V2/V3（Eta 兼容）")
    p.add_argument("--template", help="模板 JSON（V1/V2/V3 均可）")
    p.add_argument("--fields", help="字段覆盖 JSON（合并进 data）")
    p.add_argument("--worldbook", help="世界书 JSON（character_book 或 entries 数组）")
    p.add_argument("--name")
    p.add_argument("--nickname")
    p.add_argument("--description")
    p.add_argument("--personality")
    p.add_argument("--scenario")
    p.add_argument("--first-mes")
    p.add_argument("--mes-example")
    p.add_argument("--creator-notes")
    p.add_argument("--system-prompt")
    p.add_argument("--post-history")
    p.add_argument("--creator", default="lustforge")
    p.add_argument("--version", default="0.1")
    p.add_argument("--tag", action="append", default=[], help="tags，可重复")
    p.add_argument("--alternate", action="append", default=[], help="备选开场，可重复")
    p.add_argument("--alternate-only", action="store_true", help="用 --alternate 覆盖模板自带的备选开场")
    p.add_argument("--level", help="写入 creator_notes 的档位标注，如 L4")
    p.add_argument("--out", default="card.json")
    p.add_argument("--png", help="同时导出 PNG（写入 chara + ccv3 双块）")
    p.add_argument("--base-png", help="作为底图的 PNG；缺省生成占位图")
    p.add_argument("--v3", action="store_true", help="输出 V3 外壳")
    args = p.parse_args(argv)

    card: Dict[str, Any] = {"spec": "chara_card_v2", "spec_version": "2.0", "data": {}}
    if args.template:
        try:
            card = normalize_card(load_json(args.template))
        except (OSError, json.JSONDecodeError) as exc:
            print(f"模板读取失败：{exc}", file=sys.stderr)
            return 1

    data = card["data"]
    if args.fields:
        try:
            data.update(load_json(args.fields))
        except (OSError, json.JSONDecodeError) as exc:
            print(f"字段文件读取失败：{exc}", file=sys.stderr)
            return 1

    set_field(data, "name", args.name)
    set_field(data, "nickname", args.nickname)
    for card_key, dest in FIELD_ARGS.items():
        set_field(data, card_key, getattr(args, dest, None))

    if args.tag:
        data["tags"] = list(dict.fromkeys(list(data.get("tags", [])) + args.tag))
    if args.alternate:
        if args.alternate_only:
            data["alternate_greetings"] = list(args.alternate)
        else:
            data["alternate_greetings"] = list(data.get("alternate_greetings", [])) + args.alternate
    if args.level:
        note = data.get("creator_notes", "")
        data["creator_notes"] = (note.rstrip() + f"\n本卡默认档位：{args.level}").strip()

    if args.worldbook:
        try:
            ensure_book(card, load_json(args.worldbook))
        except (OSError, json.JSONDecodeError) as exc:
            print(f"世界书读取失败：{exc}", file=sys.stderr)
            return 1
    else:
        ensure_book(card, None)

    data.setdefault("extensions", {})
    data.setdefault("tags", [])

    if not data.get("name"):
        print("缺少 name：用 --name 指定", file=sys.stderr)
        return 1
    if not data.get("description"):
        print("警告：description 为空，模型会缺少人设", file=sys.stderr)

    out_card = to_v3(card) if args.v3 else card
    out_dir = os.path.dirname(os.path.abspath(args.out))
    os.makedirs(out_dir, exist_ok=True)
    with open(args.out, "w", encoding="utf-8") as fh:
        json.dump(out_card, fh, ensure_ascii=False, indent=2)
        fh.write("\n")
    print(f"已写入 {args.out}（{out_card['spec']}）")

    if args.png:
        os.makedirs(os.path.dirname(os.path.abspath(args.png)), exist_ok=True)
        v3 = to_v3(card)
        write_card_png(args.png, card, v3, args.base_png)
        print(f"已写入 {args.png}（chara + ccv3 双块，{os.path.getsize(args.png)} 字节）")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
