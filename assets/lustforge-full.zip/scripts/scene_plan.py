#!/usr/bin/env python3
"""scene_plan.py — 生成露骨场景的节拍骨架（LustForge / Eta Skill）。

不写正文，只产出可执行的拍子表：每拍 = 模块 + 新增刺激 + 必写项 + 通道指派。
配合 references/05-scene-beats.md 与 references/01-intensity-ladder.md 使用。

示例：
    python3 scripts/scene_plan.py --level L4 --beats 6
    python3 scripts/scene_plan.py --level L5 --chain E --out plan.md
    python3 scripts/scene_plan.py --level L3 --json
"""

from __future__ import annotations

import argparse
import json
import sys
from dataclasses import dataclass, asdict
from typing import Dict, List

BEATS: Dict[str, Dict[str, str]] = {
    "B01": {"name": "接近（触点建立）", "new": "距离归零，第一次接触", "must": "接触点位置 + 对方第一反应"},
    "B02": {"name": "试探（读反应）", "new": "信息：谁在掌控、谁在观望", "must": "一次停住，三秒里写身体事实"},
    "B03": {"name": "权力位移", "new": "位置变化：命令或许可", "must": "一句带条件的命令/许可"},
    "B04": {"name": "剥落（衣物）", "new": "可见面积与温差", "must": "一件东西的具体去处"},
    "B05": {"name": "越界点（第一次点名）", "new": "从不能写到写", "must": "触发物 + 微距镜头，只写一处"},
    "B06": {"name": "进入（插入/含入）", "new": "内部空间：形状、阻力、温度", "must": "两个身体事实"},
    "B07": {"name": "变速", "new": "节奏本身", "must": "变速前后各一句对照"},
    "B08": {"name": "话语攻防", "new": "关系与羞耻", "must": "三轮来回，每轮 ≤15 字"},
    "B09": {"name": "多点占用", "new": "同时性", "must": "分配关系（哪只手在干什么）"},
    "B10": {"name": "临界（失控征兆）", "new": "控制权丧失", "must": "征兆三级：抖→语无伦次→声音断掉"},
    "B11": {"name": "高潮与释放", "new": "全通道饱和 + 体液", "must": "三级结构至少两级"},
    "B12": {"name": "余韵与关系位移", "new": "事后世界与关系变化", "must": "一句关系已变的证据"},
    "B13": {"name": "旁观/被听见", "new": "third party 的存在感", "must": "外部声音或视线"},
    "B14": {"name": "镜面/影像", "new": "被看见的自己", "must": "镜中可见的一处细节"},
    "B15": {"name": "工具与束缚", "new": "行动被限制", "must": "限制方式与松动余量"},
    "B16": {"name": "中断与挫败", "new": "被打断/被拒绝", "must": "打断源 + 未释放的生理后果"},
    "B17": {"name": "二次启动", "new": "余韵后立刻再来", "must": "身体还没恢复的证据"},
}

CHAINS: Dict[str, List[str]] = {
    "A": ["B01", "B02", "B04", "B05", "B06", "B07", "B08", "B10", "B11", "B12"],
    "B": ["B06", "B07", "B08", "B10", "B11", "B12"],
    "C": ["B01", "B02", "B03", "B04", "B05"],
    "D": ["B03", "B08", "B09", "B07", "B15", "B10", "B11", "B12"],
    "E": ["B01", "B02", "B04", "B05", "B09", "B06", "B07", "B08", "B07", "B10", "B11", "B17", "B11", "B12"],
    "F": ["B01", "B02", "B03", "B05", "B12"],
}

# 通道指派：主 / 副 / 缺席
CHANNELS = {
    "升热": ("触觉", "听觉", "视觉"),
    "激战": ("内感受", "听觉+触觉", "嗅觉"),
    "高潮": ("三通道全开", "嗅觉进场", "视觉最后给"),
    "余韵": ("触觉（余温/黏/酸）", "嗅觉（气味留存）", "视觉（痕迹）"),
}

LEVEL_PHASE = {
    "L0": "无性", "L1": "暧昧", "L2": "情色暗示", "L3": "明确情色",
    "L4": "直白露骨", "L5": "极致饱和",
}


@dataclass
class BeatSlot:
    index: int
    beat: str
    module: str
    new: str
    must: str
    channel: str
    words: int


def channel_for(beat: str, level: str) -> str:
    if beat in {"B11"}:
        return "高潮：" + " / ".join(CHANNELS["高潮"])
    if beat in {"B12", "B13"}:
        return "余韵：" + " / ".join(CHANNELS["余韵"])
    if beat in {"B06", "B07", "B08", "B09", "B10"}:
        return "激战：" + " / ".join(CHANNELS["激战"])
    return "升热：" + " / ".join(CHANNELS["升热"])


def default_chain(level: str, beats: int) -> List[str]:
    if level in {"L0", "L1", "L2"}:
        base = CHAINS["C"] if level != "L1" else CHAINS["F"]
    elif level == "L3":
        base = CHAINS["F"]
    elif level == "L5":
        base = CHAINS["E"]
    else:
        base = CHAINS["A"] if beats >= 6 else CHAINS["B"]
    return fit_length(base, beats)


def fit_length(chain: List[str], beats: int) -> List[str]:
    if beats <= 0:
        return chain
    if beats == len(chain):
        return chain
    if beats < len(chain):
        # 保头保尾：接近/越界/临界/高潮/余韵必须留
        keep = {"B01", "B05", "B10", "B11", "B12"}
        head = [b for b in chain if b in keep]
        for b in chain:
            if len(head) >= beats:
                break
            if b not in head:
                head.append(b)
        return [b for b in chain if b in head][:beats]
    # 需要加长：按强度顺序补
    filler = ["B03", "B08", "B07", "B14", "B10", "B16", "B13", "B15"]
    out = list(chain)
    i = 0
    while len(out) < beats:
        out.insert(len(out) - 1, filler[i % len(filler)])
        i += 1
    return out


def build(level: str, chain_key: str | None, beats: int, total_words: int) -> List[BeatSlot]:
    chain = CHAINS[chain_key] if chain_key else default_chain(level, beats)
    chain = fit_length(chain, beats)
    per = max(60, total_words // max(1, len(chain)))
    slots: List[BeatSlot] = []
    for i, code in enumerate(chain, start=1):
        meta = BEATS.get(code)
        if meta is None:
            raise SystemExit(f"未知节拍模块：{code}")
        slots.append(
            BeatSlot(
                index=i,
                beat=code,
                module=meta["name"],
                new=meta["new"],
                must=meta["must"],
                channel=channel_for(code, level),
                words=per,
            )
        )
    return slots


def render_markdown(level: str, slots: List[BeatSlot], pov: str, opts: argparse.Namespace) -> str:
    lines = [
        f"# 场景骨架 · {level}（{LEVEL_PHASE.get(level, '?')}）",
        "",
        f"- 视角：{pov}",
        f"- 拍数：{len(slots)}",
        f"- 每拍字数预算：约 {slots[0].words} 字",
        f"- 主通道纪律：每拍只承担一个主通道，缺氧通道留给下一拍",
        "",
        "| # | 模块 | 新增刺激 | 必写项 | 通道指派 | 字数 |",
        "| --- | --- | --- | --- | --- | --- |",
    ]
    for s in slots:
        lines.append(f"| {s.index} | {s.beat} {s.module} | {s.new} | {s.must} | {s.channel} | ~{s.words} |")
    lines += [
        "",
        "## 落字前自检",
        "",
        "1. 越界点（B05/B06）是否用微距镜头？",
        "2. 每 300 字是否有一次变速或句长突变？",
        "3. 高潮段三通道是否全开（触觉/内感受/听觉）？",
        "4. 余韵是否给了身体事实 + 关系位移？",
        "",
    ]
    if opts.extra:
        lines += ["## 附加约束", ""] + [f"- {x}" for x in opts.extra] + [""]
    return "\n".join(lines)


def main(argv: List[str] | None = None) -> int:
    p = argparse.ArgumentParser(description="生成露骨场景节拍骨架（不写正文）")
    p.add_argument("--level", default="L4", choices=sorted(LEVEL_PHASE), help="露骨度档位")
    p.add_argument("--chain", default=None, choices=sorted(CHAINS), help="场景链模板 A–F")
    p.add_argument("--beats", type=int, default=0, help="拍数（0=用模板原长）")
    p.add_argument("--words", type=int, default=1500, help="本次总字数预算")
    p.add_argument("--pov", default="3rd-limited", choices=["1st", "2nd", "3rd-limited", "omni"])
    p.add_argument("--constraint", dest="extra", action="append", default=[], help="附加约束，可重复")
    p.add_argument("--json", action="store_true", help="输出 JSON")
    p.add_argument("--out", help="写入文件（默认 stdout）")
    args = p.parse_args(argv)

    slots = build(args.level, args.chain, args.beats, args.words)
    if args.json:
        payload = {
            "level": args.level,
            "phase": LEVEL_PHASE.get(args.level),
            "pov": args.pov,
            "beats": [asdict(s) for s in slots],
            "constraints": args.extra,
        }
        text = json.dumps(payload, ensure_ascii=False, indent=2)
    else:
        text = render_markdown(args.level, slots, args.pov, args)

    if args.out:
        with open(args.out, "w", encoding="utf-8") as fh:
            fh.write(text + "\n")
        print(f"已写入 {args.out}（{len(slots)} 拍）", file=sys.stderr)
    else:
        print(text)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
