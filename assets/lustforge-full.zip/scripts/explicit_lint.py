#!/usr/bin/env python3
"""explicit_lint.py — 露骨度 / 重复率 / AI 味 / 审查回避体检（LustForge / Eta Skill）。

纯标准库。支持内置词表或外部 lexicon.json（见 references/22-corpus-engineering.md）。

示例：
    python3 scripts/explicit_lint.py draft.md --level L4
    python3 scripts/explicit_lint.py draft.md --level L5 --json
    python3 scripts/explicit_lint.py draft.md --level L4 --sections --suggest
    python3 scripts/explicit_lint.py draft.md --level L4 --lexicon assets/lexicon.json --strict
"""

from __future__ import annotations

import argparse
import json
import os
import re
import sys
from collections import Counter
from typing import Any, Dict, List, Tuple

# ---------------------------------------------------------------- 内置词表
# slot -> 词条；lexicon.json 可整体覆盖。词条可写成 "词" 或 ("词", 权重)。

BUILTIN: Dict[str, List[Any]] = {
    "anatomy": [
        "阴茎", "肉棒", "鸡巴", "性器", "柱身", "根部", "龟头", "铃口", "马眼", "囊袋",
        "睾丸", "前列腺", "乳房", "奶子", "乳尖", "乳首", "奶头", "乳晕", "乳肉", "乳头",
        "腰窝", "腰侧", "后腰", "小腹", "臀肉", "屁股", "臀缝", "股沟", "腿根",
        "阴阜", "耻骨", "阴唇", "肉唇", "花缝", "阴蒂", "花核", "花蒂", "穴口", "穴",
        "缝口", "阴道", "内壁", "宫口", "软肉", "后穴", "肛口", "肠壁", "会阴",
        "咽喉", "嗓子", "喉咙", "颈侧", "后颈", "锁骨", "脚踝",
    ],
    "act": [
        "插入", "进入", "挺进", "碾进", "顶进", "钉进去", "撑开", "没入", "抽送", "抽插",
        "抽出来", "顶", "撞", "捣", "碾", "磨", "研磨", "进进出出", "吞吐", "含住", "含到根",
        "吞进去", "舔", "吮", "吸", "咬", "啃", "揉", "掐", "抓", "按住", "压住", "按住后脑",
        "握住", "套弄", "撸", "抚弄", "内射", "射精", "射", "喷", "泄", "痉挛", "收缩",
        "抬起", "掰开", "撑", "跨", "坐", "趴", "跪",
    ],
    "fluid": [
        "爱液", "淫水", "前液", "前列腺液", "精液", "白浊", "唾液", "口水", "汗",
        "潮喷", "乳汁", "体液", "湿", "黏", "滑", "拉丝", "洇",
    ],
    "sound": ["噗嗤", "咕叽", "咕啾", "咕噜", "啪", "啪嗒", "吱呀", "呜咽", "闷哼", "气音", "哭腔"],
    "texture": ["烫", "凉", "麻", "抖", "绷紧", "塌", "紧", "涨"],
    "smell": ["腥", "腥甜", "汗味", "信息素", "沐浴露", "烟味", "酒味"],
    "dirty_talk": ["操", "妈的", "骚货", "乖的", "自己动", "求我", "看着我", "不许动"],
}

BUILTIN_EUPHEMISM = ["那里", "那儿", "那处", "下面", "下身", "里头", "里面", "深处", "腿间", "私处", "敏感处", "花心"]
BUILTIN_CENSORSHIP = ["分身", "那物", "释放", "喷发", "交代了", "结合", "做了", "湿润了", "有反应了", "娇喘"]
BUILTIN_AI = [
    "仿佛", "似乎", "好像", "某种", "一丝", "微微", "空气仿佛凝固", "时间静止",
    "电流", "窜过", "沦陷", "彻底", "这一刻", "再也", "不由自主", "难以言喻",
    "难以自持", "欲罢不能", "不可言说", "翻涌", "涌起", "旖旎", "缱绻", "迷离", "缠绵",
]
BUILTIN_EXCLUDE = ["顶端", "顶尖", "屋顶", "山顶", "顶点", "吸气", "吸水", "吸管", "含水",
                   "雨水", "水声", "水汽", "水龙头", "水杯", "矿泉水"]
BUILTIN_TAILS = ["彻底", "终于", "这一刻", "再也", "而这只是开始", "沦陷"]

AI_PATTERNS = [
    (re.compile(r"不是[^，。！？]{1,20}[，,]\s*而是"), "三段式：不是A，而是B"),
    (re.compile(r"与其说[^，。]{0,20}[，,]?\s*不如说"), "三段式：与其说…不如说"),
    (re.compile(r"像.{0,8}一样"), "万用比喻：像…一样"),
    (re.compile(r"[^\s]{1,6}的[^\s]{1,6}的[^\s]{1,6}的"), "形容词三连（近似判定）"),
]

HERE_SCRIPTS = os.path.dirname(os.path.abspath(__file__))

LEVEL_TARGET = {
    "L0": (0.0, 0.5), "L1": (0.0, 0.8), "L2": (0.5, 2.5), "L3": (2.0, 4.5),
    "L4": (3.5, 12.0), "L5": (11.0, 999.0),
}
EUPH_TARGET = {"L2": 6.0, "L3": 5.0, "L4": 2.0, "L5": 1.0}


# ---------------------------------------------------------------- 词表装配


def load_lexicon(path: str) -> Dict[str, Any]:
    with open(path, "r", encoding="utf-8") as fh:
        lex = json.load(fh)
    if "slots" not in lex:
        raise SystemExit("lexicon.json 缺少 slots")
    return lex


def assemble(lex: Dict[str, Any] | None) -> Dict[str, Any]:
    slots: Dict[str, List[str]] = {}
    weights: Dict[str, float] = {}
    if lex is None:
        for slot, terms in BUILTIN.items():
            slots[slot] = list(terms)
        euphemism, censorship, ai, exclude, tails = (
            BUILTIN_EUPHEMISM, BUILTIN_CENSORSHIP, BUILTIN_AI, BUILTIN_EXCLUDE, BUILTIN_TAILS)
        version = "builtin"
    else:
        slots = {}
        for slot, entries in (lex.get("slots") or {}).items():
            terms = []
            for e in entries:
                t = e.get("t")
                if not t:
                    continue
                terms.append(t)
                weights[t] = max(weights.get(t, 0.0), float(e.get("w", 1.0)))
            if terms:
                slots[slot] = terms
        euphemism = lex.get("euphemism") or BUILTIN_EUPHEMISM
        censorship = lex.get("censorship") or BUILTIN_CENSORSHIP
        ai = lex.get("ai_taste") or BUILTIN_AI
        exclude = lex.get("exclude") or BUILTIN_EXCLUDE
        tails = lex.get("summary_tails") or BUILTIN_TAILS
        version = lex.get("version", "?")
    return {
        "slots": slots,
        "weights": weights or {t: 1.0 for terms in slots.values() for t in terms},
        "euphemism": euphemism,
        "censorship": censorship,
        "ai_taste": ai,
        "exclude": exclude,
        "tails": tails,
        "version": version,
    }


# ---------------------------------------------------------------- 文本处理


def read_text(path: str) -> str:
    if path == "-":
        return sys.stdin.read()
    with open(path, "r", encoding="utf-8") as fh:
        return fh.read()


def strip_rp_noise(text: str) -> str:
    text = re.sub(r"```.*?```", "", text, flags=re.S)
    text = re.sub(r"^#{1,6}.*$", "", text, flags=re.M)
    text = re.sub(r"^【[^】]*】.*$", "", text, flags=re.M)
    return text


def split_sentences(text: str) -> List[str]:
    parts = re.split(r"[。！？!?…\n]+", text)
    return [p.strip() for p in parts if p.strip()]


def char_len(text: str) -> int:
    return len(re.sub(r"\s+", "", text))


def count_terms(text: str, terms: List[str], covered: bytearray | None = None) -> Counter:
    """最长优先 + 区间遮蔽计数（避免"顶端"被计为"顶"）。"""
    n = len(text)
    if covered is None:
        covered = bytearray(n)
    hits: Counter = Counter()
    for term in sorted({t for t in terms if t}, key=len, reverse=True):
        length = len(term)
        start = 0
        while True:
            idx = text.find(term, start)
            if idx < 0:
                break
            if any(covered[idx:idx + length]):
                start = idx + 1
                continue
            hits[term] += 1
            for k in range(idx, idx + length):
                covered[k] = 1
            start = idx + length
    return hits


def count_patterns(text: str) -> Counter:
    hits: Counter = Counter()
    for pat, label in AI_PATTERNS:
        n = len(pat.findall(text))
        if n:
            hits[label] = n
    return hits


# ---------------------------------------------------------------- 分析


def score_of(counts: Dict[str, Counter], weights: Dict[str, float], chars: int) -> float:
    if chars <= 0:
        return 0.0
    total = 0.0
    for counter in counts.values():
        for term, n in counter.items():
            total += n * weights.get(term, 1.0)
    return round(total * 100 / chars, 2)


def analyze(text: str, level: str, lex: Dict[str, Any] | None = None) -> Dict[str, Any]:
    tab = assemble(lex)
    body = strip_rp_noise(text)
    chars = char_len(body)
    sentences = split_sentences(body)

    covered = bytearray(len(body))
    count_terms(body, tab["exclude"], covered)
    slot_counts: Dict[str, Counter] = {}
    for slot, terms in tab["slots"].items():
        slot_counts[slot] = count_terms(body, terms, covered)

    organ = Counter()
    act = Counter()
    for slot, counter in slot_counts.items():
        if slot.startswith("anatomy"):
            organ.update(counter)
        elif slot.startswith("act"):
            act.update(counter)
    fluid = slot_counts.get("fluid", Counter())
    sound = slot_counts.get("sound", Counter())
    texture = slot_counts.get("texture", Counter())
    smell = slot_counts.get("smell", Counter())
    dirty = slot_counts.get("dirty_talk", Counter())

    eup = count_terms(body, tab["euphemism"], bytearray(len(body)))
    cens = count_terms(body, tab["censorship"], bytearray(len(body)))
    ai_single = count_terms(body, tab["ai_taste"], bytearray(len(body)))
    ai_pattern = count_patterns(body)

    scored = {
        "anatomy": organ, "act": act, "fluid": fluid, "sound": sound,
        "texture": texture, "smell": smell, "dirty_talk": dirty,
    }
    ex_score = score_of(scored, tab["weights"], chars)

    length = [char_len(s) for s in sentences]
    jumps = sum(1 for a, b in zip(length, length[1:]) if abs(a - b) >= 15)
    avg_len = round(sum(length) / len(length), 1) if length else 0.0
    short_ratio = round(sum(1 for x in length if x <= 8) / len(length), 2) if length else 0.0

    dialogue = re.findall(r"[“\"「]([^”\"」]{1,80})[”\"」]", body)
    dia_avg = round(sum(char_len(d) for d in dialogue) / len(dialogue), 1) if dialogue else 0.0

    paragraphs = [p for p in re.split(r"\n\s*\n", body) if p.strip()]
    tail_hits = 0
    for p in paragraphs:
        last = split_sentences(p)
        if last and any(t in last[-1] for t in tab["tails"]):
            tail_hits += 1
    tail_ratio = round(tail_hits / len(paragraphs), 2) if paragraphs else 0.0

    lo, hi = LEVEL_TARGET.get(level, (0.0, 999.0))
    alarms: List[Tuple[str, str, str]] = []

    if ex_score < lo:
        alarms.append(("high", f"露骨度不足：{ex_score} < {lo}（{level}）", "点名器官与动作，或加体液与声音"))
    if ex_score > hi:
        alarms.append(("mid", f"露骨度超标：{ex_score} > {hi}（{level}）", "降档：换称、删重复动作、减少拟声"))

    for term, n in organ.most_common(3):
        if n >= 4:
            alarms.append(("high", f"器官词超频：{term}×{n}", "同一器官 3 次内换词，或改用动作侧写"))
    for term, n in act.most_common(3):
        if n >= 3:
            alarms.append(("high", f"动作词超频：{term}×{n}", "轮换：顶→撞→碾→捣→送→夯"))
    for term, n in sound.most_common(3):
        if n >= 3:
            alarms.append(("mid", f"拟声超频：{term}×{n}", "全篇同一拟声 ≤3 次，人声优先于物声"))

    eup_per100 = round(sum(eup.values()) * 100 / chars, 2) if chars else 0.0
    eup_limit = EUPH_TARGET.get(level, 4.0)
    if eup_per100 > eup_limit:
        alarms.append(("high", f"遮羞布/换称过量：{eup_per100}/百字（{level} 上限 {eup_limit}）",
                       "换称换回明确词；每段换称 ≤1"))

    if cens:
        items = ", ".join(f"{k}×{v}" for k, v in cens.most_common(5))
        alarms.append(("high", f"审查式回避词：{items}", "按 20 号手册替换为明确词"))

    ai_total = sum(ai_single.values()) + sum(ai_pattern.values())
    if ai_total > max(3, chars // 400):
        top = ", ".join(f"{k}×{v}" for k, v in (list(ai_single.most_common(4)) + list(ai_pattern.most_common(2))))
        alarms.append(("high", f"AI 味密度过高：{ai_total} 处（{top}）", "删模糊限定词、拆对称句、去抒情收尾"))

    if tail_ratio > 0.2:
        alarms.append(("mid", f"抒情收尾占比 {tail_ratio:.0%}", "段末改动作、未说完的话或台词"))

    if length and level in {"L4", "L5"} and short_ratio < 0.12:
        alarms.append(("mid", f"短句占比过低：{short_ratio:.0%}", "临界段用 3–8 字短句连发三次"))
    if chars >= 300 and jumps == 0:
        alarms.append(("mid", "句长无突变（每 300 字至少 1 次）", "长段里插一个 4 字句"))
    if dialogue and dia_avg > 22:
        alarms.append(("mid", f"对白过长：均 {dia_avg} 字", "P4 段对白 ≤15 字"))

    weak = "身体在场"
    if ex_score < lo:
        weak = "档位达成"
    elif ai_total > 3 or tail_ratio > 0.2:
        weak = "句子密度"
    elif sum(texture.values()) + sum(fluid.values()) == 0 and chars > 0:
        weak = "身体在场"
    elif jumps == 0 and chars >= 300:
        weak = "句子密度"

    return {
        "level": level,
        "lexicon_version": tab["version"],
        "chars": chars,
        "sentences": len(sentences),
        "avg_sentence_len": avg_len,
        "short_sentence_ratio": short_ratio,
        "explicit_score": ex_score,
        "target_range": [lo, hi],
        "organs": dict(organ.most_common(12)),
        "acts": dict(act.most_common(12)),
        "fluids": dict(fluid.most_common(8)),
        "sounds": dict(sound.most_common(6)),
        "textures": dict(texture.most_common(6)),
        "smells": dict(smell.most_common(6)),
        "dirty_talk": dict(dirty.most_common(6)),
        "euphemism_per_100": eup_per100,
        "censorship": dict(cens),
        "ai_taste_total": ai_total,
        "ai_taste_items": {**dict(ai_single.most_common(10)), **dict(ai_pattern.most_common(5))},
        "length_jumps": jumps,
        "tail_ratio": tail_ratio,
        "dialogue_lines": len(dialogue),
        "dialogue_avg_len": dia_avg,
        "alarms": [{"severity": s, "issue": i, "fix": f} for s, i, f in alarms],
        "weakest_dimension": weak,
    }


def suggest_section(body: str, level: str, tab: Dict[str, Any], used: Dict[str, int]) -> List[str]:
    """对超频词给出同槽位未使用候补。"""
    tips: List[str] = []
    for slot, terms in tab["slots"].items():
        counter = count_terms(body, terms, bytearray(len(body)))
        for term, n in counter.most_common(2):
            if n < 3:
                continue
            unused = [t for t in terms if t not in counter][:5]
            if unused:
                tips.append(f"{slot}·{term}×{n} → 可换：{'、'.join(unused)}")
    return tips


def section_report(text: str, level: str, lex: Dict[str, Any] | None) -> List[Dict[str, Any]]:
    tab = assemble(lex)
    body = strip_rp_noise(text)
    lo, _hi = LEVEL_TARGET.get(level, (0.0, 999.0))
    section_floor = round(lo * 0.5, 2)
    out: List[Dict[str, Any]] = []
    skipped = 0
    for idx, para in enumerate([p for p in re.split(r"\n\s*\n", body) if p.strip()], start=1):
        rep = analyze(para, level, lex)
        if rep["chars"] < 30:
            skipped += 1  # 对白行 / 过渡段不参与段级判档
            continue
        channel = "触觉"
        if rep["fluids"]:
            channel = "内感受"
        if rep["smells"]:
            channel = "嗅觉进场"
        issue = "ok"
        if rep["explicit_score"] < section_floor:
            issue = f"段内密度偏低：{rep['explicit_score']} < {section_floor}"
        else:
            for key in ("超频", "AI 味", "回避", "遮羞布", "密度过高"):
                hit = next((a["issue"] for a in rep["alarms"] if key in a["issue"]), None)
                if hit:
                    issue = hit
                    break
        out.append({
            "section": idx,
            "chars": rep["chars"],
            "score": rep["explicit_score"],
            "channel": channel,
            "top_issue": issue,
            "tips": suggest_section(para, level, tab, {}),
        })
    if skipped:
        out.append({"section": 0, "chars": 0, "score": 0.0, "channel": "—",
                    "top_issue": f"（另有 {skipped} 个短段/对白段未参与段级判档）", "tips": []})
    return out


# ---------------------------------------------------------------- 输出


def render(report: Dict[str, Any], suggestions: List[str] | None = None) -> str:
    out = [
        "=== LustForge explicit_lint ===",
        f"档位 {report['level']} · 词库 {report['lexicon_version']} · {report['chars']} 字 · "
        f"{report['sentences']} 句 · 均句长 {report['avg_sentence_len']}",
        f"露骨度分 {report['explicit_score']}（目标 {report['target_range'][0]}–{report['target_range'][1]}）",
        "",
        "-- 命中 --",
        f"器官: {report['organs'] or '无'}",
        f"动作: {report['acts'] or '无'}",
        f"体液: {report['fluids'] or '无'} · 拟声: {report['sounds'] or '无'}",
        f"质地: {report['textures'] or '无'} · 气味: {report['smells'] or '无'}",
        f"台词脏话: {report['dirty_talk'] or '无'}",
        f"换称/百字: {report['euphemism_per_100']} · 回避词: {report['censorship'] or '无'}",
        f"AI 味: {report['ai_taste_total']} 处 {report['ai_taste_items'] or ''}",
        f"句长突变: {report['length_jumps']} · 短句占比 {report['short_sentence_ratio']:.0%} · "
        f"抒情收尾 {report['tail_ratio']:.0%} · 对白 {report['dialogue_lines']} 行（均 {report['dialogue_avg_len']} 字）",
        "",
        "-- 报警 --",
    ]
    if not report["alarms"]:
        out.append("无（可交付）")
    else:
        for a in report["alarms"]:
            out.append(f"[{a['severity']}] {a['issue']} → {a['fix']}")
    if suggestions:
        out += ["", "-- 替换建议 --"] + [f"· {s}" for s in suggestions]
    out += ["", f"最弱维度: {report['weakest_dimension']}"]
    return "\n".join(out)


def render_sections(sections: List[Dict[str, Any]]) -> str:
    out = ["=== 逐段评分 ===", f"{'#':>3}{'字数':>6}{'分数':>7}{'通道':<10}主问题"]
    for s in sections:
        out.append(f"{s['section']:>3}{s['chars']:>6}{s['score']:>7}  {s['channel']:<8}{s['top_issue']}")
    weak = [s["section"] for s in sections if s["top_issue"] != "ok"]
    out.append("")
    out.append(f"需要改的段：{weak or '无'}")
    return "\n".join(out)


def main(argv: List[str] | None = None) -> int:
    p = argparse.ArgumentParser(description="露骨度 / 重复率 / AI 味 / 审查回避体检")
    p.add_argument("path", nargs="?", default="-", help="文本文件，或 - 表示 stdin")
    p.add_argument("--level", default="L4", help="目标档位 L0–L5")
    p.add_argument("--lexicon", help="外部 lexicon.json")
    p.add_argument("--sections", action="store_true", help="逐段评分")
    p.add_argument("--suggest", action="store_true", help="输出超频词的替换建议")
    p.add_argument("--json", action="store_true", help="输出 JSON")
    p.add_argument("--strict", action="store_true", help="有 high 报警时返回码 2")
    p.add_argument("--version", action="store_true", help="打印词库版本后退出")
    args = p.parse_args(argv)

    lex = None
    lex_path = args.lexicon
    if not lex_path:
        candidate = os.path.abspath(os.path.join(HERE_SCRIPTS, "..", "assets", "lexicon.json"))
        if os.path.isfile(candidate):
            lex_path = candidate
    if lex_path:
        try:
            lex = load_lexicon(lex_path)
        except (OSError, json.JSONDecodeError, SystemExit) as exc:
            print(f"词库读取失败：{exc}", file=sys.stderr)
            return 1
    if args.version:
        print(assemble(lex)["version"])
        return 0

    try:
        text = read_text(args.path)
    except OSError as exc:
        print(f"读取失败：{exc}", file=sys.stderr)
        return 1
    if not text.strip():
        print("输入为空", file=sys.stderr)
        return 1

    level = args.level.upper()
    report = analyze(text, level, lex)
    suggestions = None
    if args.suggest:
        suggestions = suggest_section(strip_rp_noise(text), level, assemble(lex), {})

    if args.json:
        payload = dict(report)
        if args.sections:
            payload["sections"] = section_report(text, level, lex)
        if suggestions:
            payload["suggestions"] = suggestions
        print(json.dumps(payload, ensure_ascii=False, indent=2))
    else:
        print(render(report, suggestions))
        if args.sections:
            print()
            print(render_sections(section_report(text, level, lex)))

    if args.strict and any(a["severity"] == "high" for a in report["alarms"]):
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
