#!/usr/bin/env python3
"""pack_full.py — 生成唯一交付包 dist/lustforge-full.zip（单包全量）。

包结构（zip 根 = Skill 本体，唯一 SKILL.md 在根，Eta 可直接本地导入）：

    SKILL.md               ← frontmatter name=lustforge-erotica
    references/00..23      ← 24 份手册
    scripts/*.py           ← 8 个脚本
    assets/*               ← 角色卡模板 / 世界书 / lexicon
    tests/*                ← 20 条回归基准 + 样本 + 词库源
    examples/cards/*       ← 四张类型卡（json + png）
    examples/demo-card.*   ← 示例卡
    README.md · CHANGELOG.md · LICENSE · manifest.json

示例：
    python3 scripts/pack_full.py                     # 从 skill 目录运行
    python3 scripts/pack_full.py --out ../../dist    # 指定输出目录
    python3 scripts/pack_full.py --verify            # 打包后解压自检
    python3 scripts/pack_full.py --list              # 只打印将打包的文件
"""

from __future__ import annotations

import argparse
import hashlib
import os
import shutil
import subprocess
import sys
import tempfile
import zipfile
from typing import List, Tuple

HERE = os.path.dirname(os.path.abspath(__file__))
SKILL_DIR = os.path.dirname(HERE)                       # .../skills/lustforge-erotica
REPO_DIR = os.path.dirname(os.path.dirname(SKILL_DIR))  # .../lustforge
SKIP_DIRS = {"__pycache__", ".git", ".idea", "dist", "node_modules"}
SKIP_EXT = (".pyc", ".pyo", ".DS_Store")


def add_tree(items: List[Tuple[str, str]], src_root: str, zip_prefix: str = "") -> None:
    for base, dirs, files in os.walk(src_root):
        dirs[:] = [d for d in dirs if d not in SKIP_DIRS]
        for f in sorted(files):
            if f.endswith(SKIP_EXT):
                continue
            full = os.path.join(base, f)
            rel = os.path.relpath(full, src_root).replace("\\", "/")
            items.append((full, f"{zip_prefix}{rel}" if zip_prefix else rel))


def collect() -> List[Tuple[str, str]]:
    items: List[Tuple[str, str]] = []
    add_tree(items, SKILL_DIR)                     # SKILL.md + references + scripts + assets

    tests = os.path.join(REPO_DIR, "tests")
    if os.path.isdir(tests):
        add_tree(items, tests, "tests/")

    for name in ("README.md", "CHANGELOG.md", "LICENSE"):
        path = os.path.join(REPO_DIR, name)
        if os.path.isfile(path):
            items.append((path, name))

    dist = os.path.join(REPO_DIR, "dist")
    cards = os.path.join(dist, "cards")
    if os.path.isdir(cards):
        add_tree(items, cards, "examples/cards/")
    for name in ("demo-card.json", "demo-card.png", "demo-card-v3.json", "manifest.json",
                 "lexicon-from-csv.json"):
        path = os.path.join(dist, name)
        if os.path.isfile(path):
            items.append((path, f"examples/{name}" if name.startswith(("demo-", "lexicon-")) else name))

    # 去重（同一 zip 路径只留第一个）
    seen, unique = set(), []
    for full, rel in items:
        if rel in seen:
            continue
        seen.add(rel)
        unique.append((full, rel))
    return sorted(unique, key=lambda x: x[1])


def main(argv: List[str] | None = None) -> int:
    p = argparse.ArgumentParser(description="生成单包全量 ZIP（Eta 可直接导入）")
    p.add_argument("--out", default=os.path.join(REPO_DIR, "dist"), help="输出目录")
    p.add_argument("--name", default="lustforge-full.zip")
    p.add_argument("--verify", action="store_true", help="打包后解压自检（结构 + 基准）")
    p.add_argument("--list", action="store_true", help="只列出将打包的文件")
    args = p.parse_args(argv)

    items = collect()
    if args.list:
        for _full, rel in items:
            print(rel)
        print(f"\n共 {len(items)} 个文件")
        return 0

    if not any(rel == "SKILL.md" for _f, rel in items):
        print("错误：未找到 SKILL.md（请在 skill 目录内运行）", file=sys.stderr)
        return 1

    os.makedirs(args.out, exist_ok=True)
    target = os.path.join(args.out, args.name)
    if os.path.exists(target):
        os.remove(target)

    with zipfile.ZipFile(target, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
        for full, rel in items:
            zf.write(full, rel)

    with zipfile.ZipFile(target) as zf:
        bad = zf.testzip()
        names = zf.namelist()
    size = os.path.getsize(target)
    print(f"已生成 {target}")
    print(f"  {len(names)} 个文件 · {size} 字节 · CRC {'正常' if bad is None else '损坏:' + str(bad)}")
    print(f"  根 SKILL.md：{'有' if 'SKILL.md' in names else '缺失'}"
          f" · 手册 {sum(1 for n in names if n.startswith('references/'))} 份"
          f" · 脚本 {sum(1 for n in names if n.startswith('scripts/'))} 个"
          f" · 资产 {sum(1 for n in names if n.startswith('assets/'))} 个"
          f" · tests {sum(1 for n in names if n.startswith('tests/'))} 个"
          f" · 示例卡 {sum(1 for n in names if n.startswith('examples/'))} 个")
    print(f"  SHA256 {hashlib.sha256(open(target, 'rb').read()).hexdigest()}")

    if args.verify:
        py = sys.executable
        tmp = tempfile.mkdtemp(prefix="lf-full-")
        skill_root = os.path.join(tmp, "lustforge-erotica")
        try:
            with zipfile.ZipFile(target) as zf:
                zf.extractall(skill_root)

            structure = subprocess.run(
                [py, os.path.join(skill_root, "scripts", "pack_skill.py"),
                 "--skill", skill_root, "--check-only"],
                capture_output=True, text=True, encoding="utf-8", errors="replace")
            print(f"  解压后结构校验：{'通过' if structure.returncode == 0 else '失败'}")
            if structure.returncode != 0:
                print(structure.stdout, structure.stderr)

            cases = os.path.join(skill_root, "tests", "cases.json")
            if os.path.isfile(cases):
                bench = subprocess.run(
                    [py, os.path.join(skill_root, "scripts", "run_eval.py"), "--cases", cases],
                    capture_output=True, text=True, encoding="utf-8", errors="replace")
                line = next((ln for ln in bench.stdout.splitlines() if "通过率" in ln), "")
                print(f"  解压后基准：{line or '异常(' + str(bench.returncode) + ')'}")
        finally:
            shutil.rmtree(tmp, ignore_errors=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
