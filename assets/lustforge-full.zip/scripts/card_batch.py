#!/usr/bin/env python3
"""card_batch.py — 批量生成 Eta 角色卡（V2/V3 JSON，可选 PNG 双块）。

输入是一个 JSON 列表（或 {"cards": [...]}），每项是 card_build 的 CLI 参数子集：

{
  "cards": [
    {"name": "沈砚", "level": "L4", "tags": ["L4", "现代"],
     "description": "…", "personality": "…", "scenario": "…",
     "first_mes": "…", "mes_example": "…",
     "fields_file": "optional.json", "worldbook": "optional-book.json"}
  ]
}

示例：
    python3 scripts/card_batch.py --src cards.json --out ../../dist/cards --png
    python3 scripts/card_batch.py --src cards.json --out /tmp/cards --dry-run
"""

from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
from typing import Any, Dict, List

HERE = os.path.dirname(os.path.abspath(__file__))
CARD_BUILD = os.path.join(HERE, "card_build.py")

CARD_KEYS = {
    "name": "--name", "nickname": "--nickname", "description": "--description",
    "personality": "--personality", "scenario": "--scenario", "first_mes": "--first-mes",
    "mes_example": "--mes-example", "creator_notes": "--creator-notes",
    "system_prompt": "--system-prompt", "post_history": "--post-history",
    "creator": "--creator", "version": "--version", "level": "--level",
}


def load_cards(path: str) -> List[Dict[str, Any]]:
    data = json.load(open(path, "r", encoding="utf-8"))
    if isinstance(data, dict) and "cards" in data:
        data = data["cards"]
    if not isinstance(data, list):
        raise SystemExit("cards.json 需要是数组或 {\"cards\": [...]}")
    return data


def build_command(card: Dict[str, Any], out_dir: str, png: bool, v3: bool) -> List[str]:
    name = card.get("name") or "unnamed"
    safe = "".join(c for c in name if c.isalnum() or c in "-_") or "card"
    cmd = [sys.executable, CARD_BUILD, "--out", os.path.join(out_dir, f"{safe}.json")]
    for key, flag in CARD_KEYS.items():
        if card.get(key):
            cmd += [flag, str(card[key])]
    for tag in card.get("tags") or []:
        cmd += ["--tag", str(tag)]
    alts = card.get("alternate_greetings") or []
    for alt in alts:
        cmd += ["--alternate", str(alt)]
    if alts and not card.get("append_alternates"):
        cmd += ["--alternate-only"]
    if card.get("fields_file"):
        cmd += ["--fields", card["fields_file"]]
    if card.get("worldbook"):
        cmd += ["--worldbook", card["worldbook"]]
    if card.get("template"):
        cmd = cmd[:2] + ["--template", card["template"]] + cmd[2:]
    if png:
        cmd += ["--png", os.path.join(out_dir, f"{safe}.png")]
    if v3 or card.get("v3"):
        cmd += ["--v3"]
    return cmd


def main(argv: List[str] | None = None) -> int:
    p = argparse.ArgumentParser(description="批量生成角色卡")
    p.add_argument("--src", required=True, help="cards.json")
    p.add_argument("--out", required=True, help="输出目录")
    p.add_argument("--png", action="store_true", help="同时导出 PNG 双块")
    p.add_argument("--v3", action="store_true", help="输出 V3 外壳")
    p.add_argument("--dry-run", action="store_true", help="只打印命令")
    args = p.parse_args(argv)

    cards = load_cards(args.src)
    os.makedirs(args.out, exist_ok=True)
    failed = 0
    for idx, card in enumerate(cards, start=1):
        cmd = build_command(card, args.out, args.png, args.v3)
        label = card.get("name", f"#{idx}")
        if args.dry_run:
            print(" ".join(cmd))
            continue
        proc = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace")
        if proc.returncode != 0:
            failed += 1
            print(f"[{idx}] FAIL {label}\n{proc.stdout}{proc.stderr}", file=sys.stderr)
        else:
            print(f"[{idx}] ok   {label}")
    if not args.dry_run:
        print(f"\n完成：{len(cards) - failed}/{len(cards)}")
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
