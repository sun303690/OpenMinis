#!/usr/bin/env python3
"""run_eval.py — 跑 20 条回归基准（references/21-rubric-and-cases.md）。

用例格式（tests/cases.json）：
{
  "cases": [
    {"id": 1, "level": "L2", "text_file": "samples/l2.md",
     "expect": {"score": [0.5, 2.5], "forbid_categories": ["censorship"],
                "max_ai": 2, "min_jumps": 1}},
    {"id": 2, "level": "L4", "text": "……",
     "expect": {"score": [3.5, 12], "min": {"organs": 4}, "must_terms": ["射"]}}
  ]
}

断言键：
  score:[lo,hi]            露骨度分区间
  min:{report键: n}        报告字段计数下限（organs/acts/fluids/sounds/textures/smells/dirty_talk）
  max:{report键: n}        上限
  must_terms:[...]         文本必须包含
  forbid_terms:[...]       文本不得包含
  forbid_categories:[...]  语义类别不得出现（censorship/ai_taste/euphemism）
  max_ai:n                 AI 味总数上限
  min_jumps:n              句长突变下限
  dialogue_max_avg:n       对白平均字数上限
  short_min:ratio          短句占比下限

示例：
    python3 scripts/run_eval.py --cases ../../tests/cases.json
    python3 scripts/run_eval.py --cases ../../tests/cases.json --id 3 --verbose
    python3 scripts/run_eval.py --cases ../../tests/cases.json --lexicon assets/lexicon.json --json
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from typing import Any, Dict, List, Tuple

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

import explicit_lint as lint  # noqa: E402

CATEGORY_KEYS = ["censorship", "ai_taste", "euphemism"]


def load_cases(path: str) -> List[Dict[str, Any]]:
    data = json.load(open(path, "r", encoding="utf-8"))
    cases = data.get("cases") if isinstance(data, dict) else data
    if not isinstance(cases, list):
        raise SystemExit("cases.json 需要数组或 {\"cases\": [...]}")
    return cases


def resolve_text(case: Dict[str, Any], base: str) -> str:
    if "text" in case and case["text"]:
        return case["text"]
    if "text_file" in case and case["text_file"]:
        path = case["text_file"]
        if not os.path.isabs(path):
            path = os.path.join(base, path)
        with open(path, "r", encoding="utf-8") as fh:
            return fh.read()
    raise SystemExit(f"用例 {case.get('id')} 缺少 text/text_file")


def category_count(report: Dict[str, Any], name: str) -> int:
    if name == "censorship":
        return sum((report.get("censorship") or {}).values())
    if name == "ai_taste":
        return int(report.get("ai_taste_total") or 0)
    if name == "euphemism":
        return int(report.get("euphemism_per_100") or 0)
    return 0


def check(case: Dict[str, Any], text: str, report: Dict[str, Any]) -> List[str]:
    fails: List[str] = []
    exp = case.get("expect") or {}

    if "score" in exp:
        lo, hi = exp["score"]
        if not (lo <= report["explicit_score"] <= hi):
            fails.append(f"score {report['explicit_score']} 不在 [{lo}, {hi}]")

    for key, minimum in (exp.get("min") or {}).items():
        actual = report.get(key)
        actual = len(actual) if isinstance(actual, dict) else int(actual or 0)
        if actual < minimum:
            fails.append(f"{key} {actual} < {minimum}")

    for key, maximum in (exp.get("max") or {}).items():
        actual = report.get(key)
        actual = len(actual) if isinstance(actual, dict) else int(actual or 0)
        if actual > maximum:
            fails.append(f"{key} {actual} > {maximum}")

    for term in exp.get("must_terms") or []:
        if term not in text:
            fails.append(f"缺少必需词「{term}」")

    for term in exp.get("forbid_terms") or []:
        if term in text:
            fails.append(f"出现禁用词「{term}」")

    for name in exp.get("forbid_categories") or []:
        n = category_count(report, name)
        if n:
            fails.append(f"{name} 应为 0，实际 {n}")

    if "max_ai" in exp and report["ai_taste_total"] > exp["max_ai"]:
        fails.append(f"AI 味 {report['ai_taste_total']} > {exp['max_ai']}")

    if "min_jumps" in exp and report["length_jumps"] < exp["min_jumps"]:
        fails.append(f"句长突变 {report['length_jumps']} < {exp['min_jumps']}")

    if "dialogue_max_avg" in exp and report["dialogue_avg_len"] > exp["dialogue_max_avg"]:
        fails.append(f"对白均长 {report['dialogue_avg_len']} > {exp['dialogue_max_avg']}")

    if "short_min" in exp and report["short_sentence_ratio"] < exp["short_min"]:
        fails.append(f"短句占比 {report['short_sentence_ratio']} < {exp['short_min']}")

    return fails


def main(argv: List[str] | None = None) -> int:
    p = argparse.ArgumentParser(description="跑露骨写作回归基准")
    p.add_argument("--cases", required=True, help="cases.json 路径")
    p.add_argument("--lexicon", help="外部 lexicon.json")
    p.add_argument("--id", type=int, action="append", help="只跑指定用例，可重复")
    p.add_argument("--verbose", action="store_true", help="打印每条的报告摘要")
    p.add_argument("--json", action="store_true", help="输出 JSON 结果")
    args = p.parse_args(argv)

    lex = lint.load_lexicon(args.lexicon) if args.lexicon else None
    base = os.path.dirname(os.path.abspath(args.cases))
    cases = load_cases(args.cases)
    if args.id:
        cases = [c for c in cases if int(c.get("id", -1)) in set(args.id)]
        if not cases:
            print("没有匹配的用例 id", file=sys.stderr)
            return 1

    results: List[Dict[str, Any]] = []
    passed = 0
    for case in cases:
        cid = case.get("id", "?")
        level = (case.get("level") or "L4").upper()
        try:
            text = resolve_text(case, base)
        except (OSError, SystemExit) as exc:
            results.append({"id": cid, "pass": False, "fails": [str(exc)]})
            continue
        report = lint.analyze(text, level, lex)
        fails = check(case, text, report)
        ok = not fails
        passed += 1 if ok else 0
        results.append({
            "id": cid,
            "level": level,
            "pass": ok,
            "score": report["explicit_score"],
            "weakest": report["weakest_dimension"],
            "fails": fails,
            "title": case.get("title", ""),
        })
        if not args.json:
            mark = "PASS" if ok else "FAIL"
            print(f"[{mark}] #{cid:<2} {level} score={report['explicit_score']:<6} "
                  f"{case.get('title', '')}")
            if not ok:
                for f in fails:
                    print(f"        · {f}")
            if args.verbose:
                print(f"        器官={report['organs']} 动作={report['acts']}")
                print(f"        体液={report['fluids']} AI味={report['ai_taste_total']} "
                      f"突变={report['length_jumps']} 最弱={report['weakest_dimension']}")

    total = len(results)
    rate = f"{passed}/{total}"
    if args.json:
        print(json.dumps({"passed": passed, "total": total, "results": results}, ensure_ascii=False, indent=2))
    else:
        print(f"\n通过率：{rate}（{passed / total:.0%}）" if total else "无用例")
        if passed < total:
            print("未通过项按 references/21 的 D1–D5 逐条修，优先修档位与重复。")
    return 0 if passed == total else 2


if __name__ == "__main__":
    raise SystemExit(main())
