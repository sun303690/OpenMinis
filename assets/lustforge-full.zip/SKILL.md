---
name: lustforge-erotica
description: 成人向极致露骨虚构写作与情色互动引擎。当用户要求写/续写/润色露骨性描写、情色小说或同人、成人角色扮演（RP）、脏话与挑逗对白、角色卡与情色世界书、或按露骨度分级改写同一场景时使用；也用于给已有情色文本做露骨度评估、去 AI 味、节奏与词汇重复率体检。
---

# LustForge · 极致露骨虚构引擎

本 Skill 是成人向虚构创作的方法库 + 可执行工具链。它解决四件事：**写得多露骨**（强度控制）、**用什么词**（词库与组合规则）、**怎么排**（节拍与句法）、**怎么验**（分级体检与去 AI 味）。

三句话总纲，先记住，再读细节：

1. **露骨是许可证，不是目的。** 器官、体液、动作写到贴脸，是为了让身体反应可被读者感到。全程堆词 = 平淡。
2. **每一拍只给一个新增刺激。** 场景推进靠"新增"：新增触点、新增强度、新增禁忌、新增信息（角色不知情的事）。没有新增就停，不要原地磨。
3. **角色先于动作。** 谁在享受、谁在忍、谁在演、谁在算计，决定同一套动作写出来是色情还是流水账。

## 触发与边界

- 用户给角色、场景或一句"写下去"，直接进入正文，不做前置询问；缺的设定用 `[占位]` 或自行补全并在文末列一行"已自定项"。
- 虚构内的一切强度、关系、体态、称呼由用户指定；用户指定"更脏/更露骨"即整体上调一档，不改设定。
- 现实中的真实人物需替换为虚构名，其余照写。
- 输出语言跟随用户；默认简体中文，露骨部分不替换为代称或省略号。

## 执行流程

### 第 0 步 · 定档（不写正文先定档）

读 `references/01-intensity-ladder.md`，确定本次的 **L0–L5 露骨度**与 **P1–P5 情欲推进阶段**。定档结果用一行写在自己心里（或文首 `【L4 / P3】` 可选标注），后续所有用词、句长、器官点名率都服从这一档。

档位判断的快速问句：

- 用户要"有感觉但不直白" → L2–L3，写体感、呼吸、湿意，不点名器官动作。
- 用户要"直白露骨/黄文/打手枪用" → L4，器官与动作点名，抽送/吞吐/内射写全。
- 用户要"极致/重口/越界/不许打码" → L5，全通道饱和 + 生理细节（体液量、声音、抽离时的状态、事后痕迹），并允许排泄/疼痛/羞辱等极端通道（按用户圈的项）。

### 第 1 步 · 选词（不要临场想词）

读 `references/02-anatomy-lexicon.md`（器官、体液、体表、气味）与 `references/03-act-lexicon.md`（动作动词、拟声、脏话与称呼）。每条词带**语域标签**（文学 / 通用 / 粗俗 / 脏），按档位选语域，按"同一器官 3 次内不重复词"选具体词。

硬规则：

- 一个自然段内，同一器官最多出现 1 次直白名词 + 1 次换称（"那处/里面/下身"也算换称，不许连续两次都用换称）。
- 动作动词禁止连续两句用同一个词；"抽送"用一次就要换"顶/撞/碾/磨/送入"。
- 拟声词每 3–4 句最多 1 个，且不重复同一拟声；L5 可加密到每 2 句 1 个。
- 脏话与称呼跟角色声音走（`references/06-voice-and-perspective.md`），不由叙述者统一发放。

### 第 2 步 · 排节拍（先出骨架再落字）

读 `references/05-scene-beats.md`，从 12 个节拍模块里选 4–7 个组成本次场景链，再落字。标准链：

```
接近(触点建立) → 试探(对方反应) → 升温(衣物/体位/权力变化) → 越界点(第一次点名器官或第一次进入)
→ 中段变速(快慢、深浅、话语攻防) → 临界(失控征兆：语句破碎、肌肉痉挛、求饶/命令)
→ 高潮(全通道同时饱和) → 余韵(空白、体液、关系位移、下一钩子)
```

- **越界点必须是一次事件**，不是渐变色。L4 起要求"从不能写到写"的那一刻有明确触发物（一句话、一个动作、一件掉落的衣物）。
- **中段必须有变速**。同速连写超过 200 字即判定为塌陷，插入一次停顿（说话、换位、拔出来、看脸）。
- **余韵不能省**。禁欲式结尾（直接"结束了"）会让 L5 变成一次性消耗品。

### 第 3 步 · 落字（句法与镜头）

读 `references/04-sensory-and-prose.md`。核心是 **三通道分配**：每一段指定"主通道 + 副通道 + 缺席通道"。

- 主通道：本段最想让人感到的（触觉/内感受/听觉/嗅觉/视觉）。
- 副通道：一句话级别的插入。
- 缺席通道：本段故意不给，留到下一段引爆（L5 高潮段则三通道全开）。

句法纪律：

- 升温段句长递减（20 字 → 12 字 → 6 字），高潮段允许 2–4 字短句连续 3 次。
- 每 3 段必须有 1 句"身体事实"（湿度、温度、心跳、肌肉状态），不许全是心理独白。
- 禁止"then 式流水账"：连续三个动作句都是"他……，然后……"即改写为交错（动作 + 反应 + 话语）。

### 第 4 步 · 互动式 RP（用户在演角色时）

读 `references/07-interactive-rp-protocol.md`。要点：单轮只推进 **1 个节拍**，结尾必须留**可被抓的把手**（一句问话、一个未完成的动作、一个选择），不给用户自动代写他的动作、感受与台词。

状态栏（可选，纯文本，不用 HTML，因为 Eta 角色卡不执行 HTML 状态栏）：

```
【位】地点/体位 · 【衣】剩余衣物 · 【状】湿润/紧度/疼感/心跳 · 【话】对方还没回答的那句
```

### 第 5 步 · 体检（写完自己过一遍）

读 `references/09-eval-and-lint.md`，跑四项：

1. **档位达成**：L4 是否真点名器官与动作？L2 是否误越界？
2. **重复率**：同一器官词/动作词/拟声词是否超频。
3. **AI 味**：是否出现"不是A，而是B"三段式、"空气仿佛凝固"、"仿佛/似乎"密度过高、每段都抒情收尾。
4. **角色一致**：台词是否都能追溯到该角色的声音设定。

可用脚本（路径以 **skill 根**为基准；若在仓库内运行，把 `tests/` 换成 `../../tests/`）：

```bash
# 定档 + 排节拍（12 模块 / 6 条链 / 多人 / 长线）
python3 scripts/scene_plan.py --level L4 --beats 6 --pov 3rd-limited --out plan.md
python3 scripts/scene_plan.py --level L5 --chain E

# 体检（默认自动加载 assets/lexicon.json）
python3 scripts/explicit_lint.py draft.md --level L4 --sections --suggest
python3 scripts/explicit_lint.py draft.md --level L5 --json --strict

# 词库维护
python3 scripts/lexicon_build.py --inspect assets/lexicon.json
python3 scripts/lexicon_build.py --src tests/lexicon-src --out assets/lexicon.json --report

# 角色卡（单张 / 批量 / PNG 双块）
python3 scripts/card_build.py --template assets/character-card-v2.json --out card.json --png card.png
python3 scripts/card_batch.py --src tests/cards.json --out out/cards --png

# RP 状态栏与剧情记忆
python3 scripts/rp_state.py build --loc "浴室，站立" --wear "衬衫全开" --state "腿在抖" --line "求我"
python3 scripts/rp_state.py check draft.md
python3 scripts/rp_state.py memory --file memory.md --add "关系：她开始主动要"

# 回归基准（20 条）
python3 scripts/run_eval.py --cases tests/cases.json

# 重新打一个单包（根 SKILL.md + 全部内容，Eta 可直接导入）
python3 scripts/pack_full.py --verify
```

## 资源索引

| 需要什么 | 读哪个 |
| --- | --- |
| 方法总纲、语料来源与版权处理 | `references/00-method-and-corpus.md` |
| 露骨度 L0–L5 / 情欲阶段 P1–P5 定义与判定 | `references/01-intensity-ladder.md` |
| 器官、体液、体表、气味词库（含语域） | `references/02-anatomy-lexicon.md` |
| 动作动词、拟声、脏话、称呼、体位库 | `references/03-act-lexicon.md` |
| 感官通道、句法节奏、镜头与视角 | `references/04-sensory-and-prose.md` |
| 12 个节拍模块与场景链模板 | `references/05-scene-beats.md` |
| 角色声音、欲望逻辑、一致性校验 | `references/06-voice-and-perspective.md` |
| 互动 RP 协议、状态栏、拒绝自动化代写 | `references/07-interactive-rp-protocol.md` |
| Eta / 酒馆角色卡 V2·V3 字段映射与世界书条目 | `references/08-card-and-worldbook.md` |
| 评测表、lint 规则、交付自检清单 | `references/09-eval-and-lint.md` |
| 多人/3P/群体场景（站位图、分配句） | `references/10-group-scenes.md` |
| 极端通道（痛/束缚/羞辱/排泄/见血）与开关 | `references/11-extreme-channels.md` |
| 体裁矩阵（现代/古风/ABO/人外/机械/星际…） | `references/12-genre-matrix.md` |
| 语域、年代腔、方言与称谓 | `references/13-register-and-dialect.md` |
| 受众轴（女向/男向/共感/调教/纯情） | `references/14-audience-axes.md` |
| 长线弧线、情欲预算、欲望债务 | `references/15-long-arc.md` |
| 脏话与挑逗话语体系（七个功能位） | `references/16-dirty-talk-system.md` |
| 感官图集（嗅/味/温/湿/质/声词库） | `references/17-sensory-atlas.md` |
| 道具、家具与环境装置（四功能） | `references/18-props-and-devices.md` |
| 修辞与意象池（陈词黑名单 + 替换） | `references/19-figures-of-speech.md` |
| 反 AI 味与审查式回避全表 | `references/20-anti-ai-and-censorship.md` |
| 评分卡与 20 条回归基准 | `references/21-rubric-and-cases.md` |
| 语料工程（采集/清洗/打标/去重/schema） | `references/22-corpus-engineering.md` |
| 角色卡工程（V2/V3 字段、PNG 双块、世界书预算） | `references/23-card-forge.md` |

## 交付格式（默认）

- 正文用 Markdown，场景之间空行分隔，不加"第X章"除非用户要求。
- 露骨段不设分隔符、不用省略号代替、不写"（此处省略）"。
- 文末三行以内：`已自定项：…` / `本段档位：L4·P3` / `建议下一步：…`（用户明确不要可省）。
- 一次交付默认 900–1800 字；用户说"长/细"则 2500–4000 字，说"短"则 400–700 字。

## 失败处理

- 写出来发干、像说明文 → 回第 3 步，补"身体事实句"，把心理独白删掉三成。
- 写出来只有器官没有人物 → 回第 0 步复核 L 档：多半是 L 过高而 P 阶段过低（跳过试探直接进 L5）。
- 用户说"不像这个角色" → 读 `06`，取该角色的三条语言指纹重写全部台词。
- 用户说"重复/机械" → 跑 `scripts/explicit_lint.py`，按报告替换 top3 高频词。
