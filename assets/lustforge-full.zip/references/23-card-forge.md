# 23 · 角色卡工程（V2/V3 / PNG 双块 / 世界书）—— 合并自 card-forge Skill

> 本节原为独立 Skill `lustforge-card-forge`，现并入主 Skill 作为第 23 份参考，便于单包分发。触发场景：建卡、改卡、导入导出、写 first_mes / mes_example、调世界书条目与 token 预算、排查"不触发/乱触发/出戏"。

## 一、Eta 运行时事实（先记这六条）

1. Eta 读 PNG 的 `chara`（V2）与 `ccv3`（V3）双块，优先 `ccv3`；同时含两块且一块损坏会报错，不静默降级。
2. Eta **不执行** HTML 状态栏、正则替换插件、变量、脚本、群聊、CHARX。状态栏只能是纯文本。
3. 世界书走**字面关键字**匹配。正则、概率、分组、时序等条件会让该条目被跳过；默认只扫最近两条消息。
4. 世界书预算默认 ≈ 模型窗口的 25%；超预算不截断条目，整条不进。
5. 角色会话仍能调工具；`system_prompt` 里不要禁止它做事，只约束演出方式。
6. 角色"重新生成"只改写文字，不执行设备动作。

## 二、建卡流程

1. **定档**：确定 L 档与默认 P 阶段，写进 `creator_notes` 与 `extensions.lustforge`。
2. **三块核心**：
   - `description`：外貌与身体设定（敏感点写具体部位 + 具体反应）／性格（含一条矛盾）／三条语言指纹／欲望逻辑三格／与 `{{user}}` 的关系现状。
   - `first_mes`：100–250 字，直接进场景，结尾留把手（问话 / 未完成动作 / 二选一）。
   - `mes_example`：2–3 组、每组 ≤3 轮，**必须含露骨对白**，句式互不相同。
3. **演出规则**：`system_prompt` 只写五条（单轮一拍、不代写用户、结尾留把手、保持档位、对话口吻但按实际结果回答设备操作）；`post_history_instructions` 写本轮硬约束。
4. **备选开场**：至少三条，对应 L2 / L4 / L5。
5. **世界书**：每条只写外部事实，`content` ≤200 字，常驻 ≤2 条，关键字用用户真会说的词。
6. **生成与校验**：

```bash
python3 scripts/card_build.py --template assets/character-card-v2.json \
  --fields my-fields.json --worldbook assets/worldbook-pack.json \
  --out out/card.json --png out/card.png
python3 scripts/card_batch.py --src tests/cards.json --out out/cards --png
python3 -m json.tool out/card.json > /dev/null && echo JSON_OK
```

## 三、字段规范

### 外壳

```json
{ "spec": "chara_card_v2", "spec_version": "2.0", "data": { ... } }
{ "spec": "chara_card_v3", "spec_version": "3.0", "data": { ... } }
```

V1 是扁平结构；Eta 导入自动转换，导出统一 V2/V3。**校验**：`spec` 与 `spec_version` 必须同时存在，缺 `data` 包裹会被判为 V1。

### 核心字段

| 字段 | 类型 | 语义 | 写作要点 |
| --- | --- | --- | --- |
| `name` | string | 角色名 | 会进入 `{{char}}` 宏 |
| `nickname`（V3） | string | 昵称 | 空字符串合法 |
| `description` | string | 人设主体 | 唯一"重量级"字段；分段小标题 |
| `personality` | string | 性格摘要 | 放语言指纹，一句一条 |
| `scenario` | string | 当前处境 | 写"此刻"，不写背景史 |
| `first_mes` | string | 开场白 | 直接进场景；≤250 字；结尾留把手 |
| `mes_example` | string | 示例对话 | `<START>` 分隔；每组 ≤3 轮 |
| `creator_notes` | string | 作者注 | 档位、开关项、兼容说明 |
| `system_prompt` | string | 覆盖系统提示 | 只写演出规则 |
| `post_history_instructions` | string | 历史后置指令 | 本轮硬约束（字数/档位/结尾形式） |
| `alternate_greetings` | string[] | 备选开场 | 按档位排，用户自选 |
| `tags` | string[] | 标签 | 档位与类型 |
| `creator` / `character_version` | string | 作者/版本 | 改设定必升版本 |
| `extensions` | object | 扩展 | 未知字段往返保留 |

### V3 增量

| 字段 | 语义 |
| --- | --- |
| `nickname` | 昵称 |
| `creator_notes_multilingual` | 多语言作者注（`{"en": "..."}`） |
| `group_only_greetings` | 群聊开场（Eta 不支持群聊，留空数组） |
| `source` | 来源 URL 数组 |
| `creation_date` / `modification_date` | unix 秒；可留 0 |
| `assets` | 卡内资源，Eta 不展示但保留 |

## 四、世界书（`character_book`）

```json
{
  "name": "书的名称",
  "scan_depth": 2,
  "token_budget": 900,
  "recursive_scanning": false,
  "entries": [ { "keys": ["浴室"], "content": "……", "constant": false } ]
}
```

| 条目字段 | 语义 | Eta 行为 |
| --- | --- | --- |
| `keys` | 主关键字 | **字面**匹配，正则会失效 |
| `secondary_keys` | 次关键字 | 配合 `selective` |
| `content` | 插入正文 | 建议 ≤200 字 |
| `enabled` | 是否启用 | false 完全不参与 |
| `constant` | 常驻 | 全局 ≤2 条 |
| `selective` | 是否要求次关键字 | |
| `case_sensitive` | 大小写敏感 | 中文无意义 |
| `insertion_order` | 插入顺序 | 小的先 |
| `priority` | 优先级 | 预算不足先丢低的 |
| `position` | 插入位置 | 影响相对位置 |
| `name` / `comment` | 管理用 | 不参与匹配 |

**匹配规则**：只扫最近两条消息的正文（工具输出/思考/图片不算）；未支持条件整条跳过；超预算整条不进；`constant: true` 每轮都进。

## 五、PNG 双块

| 块关键字 | 内容 |
| --- | --- |
| `chara` | base64(V2 JSON) |
| `ccv3` | base64(V3 JSON) |

导出保留原图其他块，只替换角色块；手写实现见 `scripts/card_build.py` 的 `write_card_png()`（去重旧块、IEND 前插入、CRC 正确）。

## 六、写卡的取舍原则

1. `description` 不是设定全集，是模型每轮都会读的那 1000 字；长设定进世界书。
2. 露骨演出规则放 `system_prompt` / `post_history_instructions`，不放 `description`。
3. `mes_example` 是语气锚，比任何形容词有效；必须含露骨对白。
4. 备选开场按档位排，把强度选择权交给用户。
5. 世界书只放事实，指令进 system_prompt。

## 七、卡故障速查

| 症状 | 原因 | 修 |
| --- | --- | --- |
| 卡不触发世界书 | 关键字不在用户会说的词里，或用正则 | 改字面词；`scan_depth` 保持 2 |
| 世界书乱插 | 条目写了行为指令 | 只留外部事实 |
| 角色出戏解释设定 | 设定全塞 `description` | 挪进世界书，`system_prompt` 只留规则 |
| 每轮重复同一句 | 缺语气锚 | 补 `mes_example`，句式换开 |
| 一上来写 800 字 | 开场白过长 | 压到 250 字，只留一个把手 |
| 档位乱跳 | 无硬约束 | `post_history_instructions` 写死档位与字数 |
| 导入报错 | 缺 `spec`/`spec_version` 或 data 包裹 | 用 `card_build.py` 规范化 |
| 卡越写越胖 | 单条 >200 字、常驻过多 | 拆条、常驻 ≤2 条 |

## 八、合法性自检

```bash
python3 -m json.tool card.json > /dev/null && echo JSON_OK
python3 -c "import json;d=json.load(open('card.json'));d=d.get('data',d);print(d['name'],len(d['description']),len(d['first_mes']))"
```
