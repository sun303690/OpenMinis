# 08 · Eta / 酒馆角色卡字段映射与世界书

Eta 的角色导入走 Character Card V1/V2/V3 JSON 与 PNG（`chara` = V2、`ccv3` = V3 双块），字段依据 [spec_v2](https://github.com/malfoyslastname/character-card-spec-v2) / [SPEC_V3](https://github.com/kwaroran/character-card-spec-v3)。Eta 只做常用文字卡：**不执行** HTML 状态栏、正则替换插件、变量、脚本、群聊、CHARX。

## 一、字段 → 露骨创作中的用途

| 字段 | 作用 | 情色卡怎么写 |
| --- | --- | --- |
| `name` | 角色名 | 单人卡就一个名字；同一世界观多卡共用前缀便于管理 |
| `description` | 人设主体（最重要） | 分四块：外貌与身体设定（含敏感点）／性格／欲望逻辑三格（想要·害怕·交换）／与 {{user}} 的关系现状 |
| `personality` | 性格摘要 | 写**三条语言指纹**（句长习惯、主动程度、词汇禁区），一句话一条 |
| `scenario` | 当前处境 | 写"此刻"：地点、时间、身上有什么、正在做什么、为什么停在这里 |
| `first_mes` | 开场白 | 直接进场景，100–250 字，结尾留把手；不要自我介绍式开场 |
| `mes_example` | 示例对话 | 2–3 组，每组 ≤3 轮，**必须含露骨对白**（这是最有效的语气锚） |
| `system_prompt` | 覆盖系统提示 | 只放"演出规则"：视角、单轮一拍、不代写、状态栏格式 |
| `post_history_instructions` | 历史后置指令 | 放"本轮必须"的短指令，如"保持 L4，禁止抒情收尾" |
| `alternate_greetings` | 备选开场 | 每个对应一种档位：温柔版 L2 / 直接版 L4 / 重口版 L5，让用户自选 |
| `creator_notes` | 作者注 | 档位说明、触发词、禁忌项；Eta 里仅管理用 |
| `tags` | 标签 | 用类型标签（L 档、关系、场景、warning 类） |
| `character_version` | 版本 | 改一次设定就 +0.1，便于回溯 |
| `extensions` | 扩展 | 放自定义字段；Eta 保留未知字段往返 |

## 二、V2 骨架（最小可用）

```json
{
  "spec": "chara_card_v2",
  "spec_version": "2.0",
  "data": {
    "name": "林砚",
    "description": "……",
    "personality": "……",
    "scenario": "……",
    "first_mes": "……",
    "mes_example": "<START>\n{{user}}: ……\n{{char}}: ……",
    "creator_notes": "L4 卡，重口项默认关闭",
    "system_prompt": "……",
    "post_history_instructions": "……",
    "alternate_greetings": ["……", "……"],
    "character_book": { "entries": [] },
    "tags": ["L4", "现代", "支配向"],
    "creator": "lustforge",
    "character_version": "0.1",
    "extensions": {}
  }
}
```

V3 在此基础上把 `spec` 换成 `chara_card_v3`、`spec_version` 为 `3.0`，`data` 内可用 `nickname`、`creator_notes_multilingual`、`group_only_greetings`、`source`、`creation_date`、`modification_date`、`assets[]`。Eta 同时支持，PNG 双块优先读 `ccv3`。

## 三、世界书（`character_book`）条目

单条结构（Eta 支持的关键字段）：

```json
{
  "id": 0,
  "keys": ["浴室", "洗手台"],
  "secondary_keys": ["林砚"],
  "content": "浴室里那面镜子是旧的，右下角有一道裂纹。他把人抵在洗手台上的时候，习惯让对方看着镜子。",
  "enabled": true,
  "constant": false,
  "selective": true,
  "case_sensitive": false,
  "insertion_order": 100,
  "priority": 10,
  "position": "before_char",
  "name": "浴室/镜子",
  "comment": "空间锚"
}
```

### 条目写法五条纪律

1. **只写外部事实**：地点、物件、关系史、身体设定、禁忌。不写行为指令（"她应该呻吟"），因为 Eta 世界书是字面关键字匹配，指令会随机插进对话破坏气氛。
2. **关键字用字面词**：Eta 不做正则。`keys` 里不要写 `.*浴室.*`、不要写概率、分组、时序；这些条件会让整条被跳过。
3. **一条一锚点**：一条只描述一个地点/一个物件/一段关系史，`content` ≤200 字。超长条目挤占预算（默认预算 ≈ 模型窗口 25%）。
4. **优先级分层**：`constant: true` 只给全局设定（世界观、双方关系基线）且 ≤2 条；场景锚点用 `insertion_order` 排先后。
5. **扫描深度**：Eta 默认只扫最近两条消息，`scan_depth` 设大了也不会更准；关键字要出现在用户会真的说到的词里（"浴室""镜子""门"），不要用文学化别名。

### 情色世界书条目建议清单

| 类 | 例 | keys 例 |
| --- | --- | --- |
| 空间锚 | 卧室、浴室、办公室、车内、酒店 | 该地点的常用词 |
| 物件 | 镜子、领带、酒、冰块、手铐、床单 | 物件名 |
| 身体设定 | 敏感点、疤痕、穿孔、旧伤 | 部位词 |
| 关系史 | 第一次、那次之后、约定 | "第一次""那次""约定" |
| 禁忌与红线 | 不谈什么、不许做什么 | 相关词 |
| 权力结构 | 谁付钱、谁欠谁、谁能叫停 | 关系词 |

## 四、PNG 导出

Eta 读 PNG 的 `chara`（V2 base64 JSON）与 `ccv3`（V3 base64 JSON）文本块。写法：

```bash
python3 scripts/card_build.py --template assets/character-card-v3.json \
  --name "林砚" --personality "…" --out dist/linyan.json --png dist/linyan.png --base-png assets/base.png
```

无底图时脚本会生成一张 512×768 的纯色占位图并写入两个文本块（Eta 界面不显示头像，但导出 PNG 需要图）。

## 五、Eta 特有的三条落地注意

1. **角色会话仍能调工具**：不要在 `system_prompt` 里写"你只能演角色不能做事"，那会让真实任务失败。写"对话内保持角色口吻；涉及真实操作时按实际结果回答"。
2. **剧情记忆独立**：角色记忆用 `character_memory_write`，不写现实 `MEMORY.md`；记忆里只记关系与设定变更（见 `07` 第七节）。
3. **重新生成不跑工具**：角色回复的"重新生成"只改写文字，不执行设备动作。所以别在场景里安排"我帮你定了闹钟"这种必须真执行才有意义的动作。

## 六、常见卡故障

| 故障 | 症状 | 修 |
| --- | --- | --- |
| 开场白自嗨 | 模型一上来写 800 字长文 | `first_mes` 压到 250 字内，结尾只留一个把手 |
| 不进入角色 | 每轮都解释设定 | 把设定从 `description` 挪到世界书，`system_prompt` 只留演出规则 |
| 每轮重复同一句 | 缺 `mes_example` 语气锚 | 补 2 组露骨示例对白，句式互不相同 |
| 档位乱跳 | 没有档位约束 | `post_history_instructions` 写死"保持 L4，不写抒情收尾" |
| 世界书乱插 | 条目写了行为指令或正则关键字 | 改成字面关键字 + 外部事实 |
| 卡越写越胖 | 单条世界书 >200 字、常驻条目过多 | 拆条、常驻 ≤2 条 |
